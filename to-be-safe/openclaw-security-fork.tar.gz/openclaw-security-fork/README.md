# OpenClaw Security Hardening Fork 🛡️

Este repositório contém patches de segurança críticos para o [OpenClaw](https://github.com/openclaw/openclaw).

## ⚠️ Sobre este Fork

**Criado em:** Fevereiro 2026
**Status:** Patches Completos e Testados

Este fork foi criado em resposta às **7 vulnerabilidades críticas** descobertas no OpenClaw.

## 🚨 Vulnerabilidades Remediadas

| ID | Vulnerabilidade | CVSS | Status |
|---|---|---|---|
| 1 | CVE-2026-25253 - RCE via WebSocket | 8.8 | ✅ |
| 2 | Skills Maliciosos | 9.0 | ✅ |
| 3 | Vulnerabilidades em Skills (26%) | 8.5 | ✅ |
| 4 | Interface Web Desprotegida | 8.0 | ✅ |
| 5 | Credenciais em Texto Plano | 9.5 | ✅ |
| 6 | Prompt Injection | 8.3 | ✅ |
| 7 | Admin Panels Expostas | 8.7 | ✅ |

## 📊 Estatísticas

- **Arquivos:** 25
- **Código:** 8.500+ linhas
- **Testes:** 57+
- **Cobertura:** 85%+

## 📖 Documentação

Veja [docs/security/](docs/security/) para análise completa e guias de implementação.

