/**
 * Rate Limiter para WebSocket
 * Implementa limitação de taxa por IP, usuário e global
 */
export class RateLimiter {
  private ipLimits = new Map<string, { count: number; resetTime: number }>();
  private userLimits = new Map<string, { count: number; resetTime: number }>();
  private globalLimit = { count: 0, resetTime: Date.now() };
  private readonly windowMs: number;
  private readonly maxRequestsPerIP: number;
  private readonly maxRequestsPerUser: number;
  private readonly maxRequestsGlobal: number;
  private blockList = new Set<string>();
  private validationLog: any[] = [];

  constructor(config: {
    windowMs?: number;
    maxRequestsPerIP?: number;
    maxRequestsPerUser?: number;
    maxRequestsGlobal?: number;
  } = {}) {
    this.windowMs = config.windowMs || 60000; // 1 minuto
    this.maxRequestsPerIP = config.maxRequestsPerIP || 100;
    this.maxRequestsPerUser = config.maxRequestsPerUser || 50;
    this.maxRequestsGlobal = config.maxRequestsGlobal || 10000;

    this.startCleanup();
  }

  /**
   * Valida se requisição está dentro do limite
   */
  checkLimit(ip: string, userId?: string): {
    allowed: boolean;
    reason?: string;
    remaining?: number;
    resetTime?: number;
  } {
    const now = Date.now();

    // 1. Verificar se IP está bloqueado
    if (this.blockList.has(ip)) {
      this.log('rate_limit_blocked', `IP ${ip} is blocked`, {
        ip,
        userId
      });
      return {
        allowed: false,
        reason: 'IP address is temporarily blocked'
      };
    }

    // 2. Verificar limite global
    if (this.globalLimit.resetTime + this.windowMs < now) {
      this.globalLimit = { count: 0, resetTime: now };
    }

    if (this.globalLimit.count >= this.maxRequestsGlobal) {
      this.log('rate_limit_exceeded', 'Global limit exceeded', {
        ip,
        userId,
        currentCount: this.globalLimit.count
      });
      return {
        allowed: false,
        reason: 'Global rate limit exceeded',
        remaining: 0,
        resetTime: this.globalLimit.resetTime + this.windowMs
      };
    }

    // 3. Verificar limite por IP
    let ipLimit = this.ipLimits.get(ip);
    if (!ipLimit || ipLimit.resetTime + this.windowMs < now) {
      ipLimit = { count: 0, resetTime: now };
      this.ipLimits.set(ip, ipLimit);
    }

    if (ipLimit.count >= this.maxRequestsPerIP) {
      // Bloquear IP após múltiplas violações
      if (ipLimit.count > this.maxRequestsPerIP * 2) {
        this.blockIP(ip, 15 * 60 * 1000); // Bloquear por 15 minutos
      }

      this.log('rate_limit_exceeded', `IP limit exceeded for ${ip}`, {
        ip,
        userId,
        currentCount: ipLimit.count
      });
      return {
        allowed: false,
        reason: 'IP rate limit exceeded',
        remaining: 0,
        resetTime: ipLimit.resetTime + this.windowMs
      };
    }

    // 4. Verificar limite por usuário (se fornecido)
    if (userId) {
      let userLimit = this.userLimits.get(userId);
      if (!userLimit || userLimit.resetTime + this.windowMs < now) {
        userLimit = { count: 0, resetTime: now };
        this.userLimits.set(userId, userLimit);
      }

      if (userLimit.count >= this.maxRequestsPerUser) {
        this.log('rate_limit_exceeded', `User limit exceeded for ${userId}`, {
          ip,
          userId,
          currentCount: userLimit.count
        });
        return {
          allowed: false,
          reason: 'User rate limit exceeded',
          remaining: 0,
          resetTime: userLimit.resetTime + this.windowMs
        };
      }

      userLimit.count++;
    }

    // 5. Incrementar contadores
    ipLimit.count++;
    this.globalLimit.count++;

    this.log('rate_limit_success', `Request allowed for ${ip}`, {
      ip,
      userId,
      ipCount: ipLimit.count,
      globalCount: this.globalLimit.count
    });

    return {
      allowed: true,
      remaining: this.maxRequestsPerIP - ipLimit.count,
      resetTime: ipLimit.resetTime + this.windowMs
    };
  }

  /**
   * Bloqueia um IP
   */
  blockIP(ip: string, duration: number = 900000): void {
    this.blockList.add(ip);
    console.warn(`⚠ IP ${ip} blocked for ${duration}ms`);

    // Desbloquear automaticamente após duration
    setTimeout(() => {
      this.blockList.delete(ip);
      console.log(`✓ IP ${ip} unblocked`);
    }, duration);
  }

  /**
   * Desbloqueia um IP
   */
  unblockIP(ip: string): void {
    this.blockList.delete(ip);
    console.log(`✓ IP ${ip} manually unblocked`);
  }

  /**
   * Reset manual de limite para IP
   */
  resetIPLimit(ip: string): void {
    this.ipLimits.delete(ip);
    console.log(`✓ IP limit reset for ${ip}`);
  }

  /**
   * Reset manual de limite para usuário
   */
  resetUserLimit(userId: string): void {
    this.userLimits.delete(userId);
    console.log(`✓ User limit reset for ${userId}`);
  }

  /**
   * Limpeza automática de limites expirados
   */
  private startCleanup(): void {
    setInterval(() => {
      const now = Date.now();

      // Limpar IPs
      for (const [ip, limit] of this.ipLimits.entries()) {
        if (limit.resetTime + this.windowMs < now) {
          this.ipLimits.delete(ip);
        }
      }

      // Limpar usuários
      for (const [userId, limit] of this.userLimits.entries()) {
        if (limit.resetTime + this.windowMs < now) {
          this.userLimits.delete(userId);
        }
      }
    }, this.windowMs);
  }

  /**
   * Log de rate limiting
   */
  private log(type: string, message: string, metadata: any = {}): void {
    this.validationLog.push({
      timestamp: new Date().toISOString(),
      type,
      message,
      ...metadata
    });

    // Manter últimos 10000 logs
    if (this.validationLog.length > 10000) {
      this.validationLog = this.validationLog.slice(-10000);
    }
  }

  /**
   * Obter logs
   */
  getLogs(limit: number = 100): any[] {
    return this.validationLog.slice(-limit);
  }

  /**
   * Relatório de rate limiting
   */
  getReport(): {
    activeIPLimits: number;
    activeUserLimits: number;
    blockedIPs: number;
    globalCount: number;
    totalLogs: number;
    violations: number;
  } {
    const violations = this.validationLog.filter(
      l => l.type === 'rate_limit_exceeded'
    ).length;

    return {
      activeIPLimits: this.ipLimits.size,
      activeUserLimits: this.userLimits.size,
      blockedIPs: this.blockList.size,
      globalCount: this.globalLimit.count,
      totalLogs: this.validationLog.length,
      violations
    };
  }

  /**
   * Obter IPs bloqueados
   */
  getBlockedIPs(): string[] {
    return Array.from(this.blockList);
  }

  /**
   * Obter estatísticas detalhadas
   */
  getDetailedStats(): {
    ipLimits: Record<string, any>;
    userLimits: Record<string, any>;
    blockedIPs: string[];
    globalLimit: { count: number; resetTime: number };
  } {
    const ipStats: Record<string, any> = {};
    for (const [ip, limit] of this.ipLimits.entries()) {
      ipStats[ip] = limit;
    }

    const userStats: Record<string, any> = {};
    for (const [userId, limit] of this.userLimits.entries()) {
      userStats[userId] = limit;
    }

    return {
      ipLimits: ipStats,
      userLimits: userStats,
      blockedIPs: Array.from(this.blockList),
      globalLimit: this.globalLimit
    };
  }
}

export default RateLimiter;
