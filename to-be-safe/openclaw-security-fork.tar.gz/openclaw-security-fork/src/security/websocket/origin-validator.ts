import { Request } from 'express';
import { URL } from 'url';

/**
 * Validador de origem para WebSocket e HTTP
 * Implementa whitelist e validações rigorosas de origen
 */
export class OriginValidator {
  private allowedOrigins: Set<string>;
  private allowWildcard: boolean;
  private validationLog: any[] = [];

  constructor(allowedOrigins: string[], allowWildcard: boolean = false) {
    this.allowedOrigins = new Set(allowedOrigins);
    this.allowWildcard = allowWildcard;
  }

  /**
   * Valida origem de requisição
   */
  validate(req: Request): {
    valid: boolean;
    origin?: string;
    reason?: string;
  } {
    const origin = req.headers.origin;
    const referer = req.headers.referer;

    // Preferir Origin header (mais seguro que Referer)
    const sourceOrigin = origin || referer;

    if (!sourceOrigin) {
      this.log('validation_failed', 'Missing origin header', {
        ip: req.ip,
        userAgent: req.get('user-agent')
      });
      return {
        valid: false,
        reason: 'Missing Origin/Referer header'
      };
    }

    try {
      const url = new URL(sourceOrigin);
      const originString = url.origin;

      // Verificar se está na whitelist
      if (!this.isOriginAllowed(originString)) {
        this.log('validation_failed', `Origin not in whitelist: ${originString}`, {
          ip: req.ip,
          userAgent: req.get('user-agent')
        });
        return {
          valid: false,
          origin: originString,
          reason: `Origin ${originString} not in whitelist`
        };
      }

      this.log('validation_success', originString, {
        ip: req.ip,
        userAgent: req.get('user-agent')
      });

      return {
        valid: true,
        origin: originString
      };
    } catch (error) {
      this.log('validation_error', 'Invalid URL format', {
        ip: req.ip,
        sourceOrigin,
        error: (error as any).message
      });
      return {
        valid: false,
        origin: sourceOrigin,
        reason: 'Invalid origin format'
      };
    }
  }

  /**
   * Valida se origem está na whitelist
   */
  private isOriginAllowed(origin: string): boolean {
    if (this.allowWildcard && origin === '*') {
      return true;
    }

    return this.allowedOrigins.has(origin);
  }

  /**
   * Adiciona origem à whitelist
   */
  addOrigin(origin: string): void {
    try {
      const url = new URL(origin);
      this.allowedOrigins.add(url.origin);
      console.log(`✓ Added origin to whitelist: ${url.origin}`);
    } catch (error) {
      console.error(`Invalid origin format: ${origin}`);
    }
  }

  /**
   * Remove origem da whitelist
   */
  removeOrigin(origin: string): void {
    try {
      const url = new URL(origin);
      this.allowedOrigins.delete(url.origin);
      console.log(`✓ Removed origin from whitelist: ${url.origin}`);
    } catch (error) {
      console.error(`Invalid origin format: ${origin}`);
    }
  }

  /**
   * Obtém lista de origens permitidas
   */
  getAllowedOrigins(): string[] {
    return Array.from(this.allowedOrigins);
  }

  /**
   * Log de validação
   */
  private log(type: string, message: string, metadata: any = {}): void {
    this.validationLog.push({
      timestamp: new Date().toISOString(),
      type,
      message,
      ...metadata
    });

    // Manter últimos 10000 logs
    if (this.validationLog.length > 10000) {
      this.validationLog = this.validationLog.slice(-10000);
    }
  }

  /**
   * Obter logs de validação
   */
  getLogs(limit: number = 100): any[] {
    return this.validationLog.slice(-limit);
  }

  /**
   * Relatório de validações
   */
  getReport(): {
    totalValidations: number;
    successfulValidations: number;
    failedValidations: number;
    successRate: string;
    whitelistedOrigins: number;
  } {
    const successful = this.validationLog.filter(l => l.type === 'validation_success').length;
    const failed = this.validationLog.filter(l => l.type === 'validation_failed').length;
    const total = this.validationLog.length;

    return {
      totalValidations: total,
      successfulValidations: successful,
      failedValidations: failed,
      successRate: total > 0 ? ((successful / total) * 100).toFixed(2) + '%' : '0%',
      whitelistedOrigins: this.allowedOrigins.size
    };
  }
}

export default OriginValidator;
