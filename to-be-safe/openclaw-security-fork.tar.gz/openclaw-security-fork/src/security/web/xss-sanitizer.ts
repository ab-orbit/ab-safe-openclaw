import DOMPurify from 'isomorphic-dompurify';

/**
 * Sanitizador XSS (Cross-Site Scripting)
 * Remove scripts e tags perigosas mantendo conteúdo legítimo
 */
export class XSSSanitizer {
  private validationLog: any[] = [];
  private blockedPatterns = [
    /<script[\s\S]*?<\/script>/gi,
    /on\w+\s*=\s*["'][^"']*["']/gi,
    /javascript:/gi,
    /data:text\/html/gi,
    /vbscript:/gi
  ];

  /**
   * Sanitiza string contra XSS
   */
  sanitize(input: string, strict: boolean = false): {
    sanitized: string;
    isClean: boolean;
    threats: string[];
  } {
    if (typeof input !== 'string') {
      return {
        sanitized: '',
        isClean: true,
        threats: []
      };
    }

    const threats: string[] = [];
    let sanitized = input;

    // 1. Detectar padrões perigosos
    for (const pattern of this.blockedPatterns) {
      const matches = sanitized.match(pattern);
      if (matches) {
        threats.push(...matches);
        sanitized = sanitized.replace(pattern, '');
      }
    }

    // 2. Usar DOMPurify para limpeza rigorosa
    const config = strict
      ? {
          ALLOWED_TAGS: ['b', 'i', 'em', 'strong', 'br', 'p'],
          ALLOWED_ATTR: [],
          KEEP_CONTENT: true
        }
      : {
          ALLOWED_TAGS: [
            'b', 'i', 'em', 'strong', 'a', 'p', 'br',
            'ul', 'ol', 'li', 'code', 'pre'
          ],
          ALLOWED_ATTR: ['href', 'title'],
          KEEP_CONTENT: true
        };

    sanitized = DOMPurify.sanitize(sanitized, config);

    // 3. Validar comprimento
    const MAX_LENGTH = 10000;
    if (sanitized.length > MAX_LENGTH) {
      threats.push(`Content exceeds max length of ${MAX_LENGTH}`);
      sanitized = sanitized.slice(0, MAX_LENGTH);
    }

    const isClean = threats.length === 0;

    this.log('sanitization', {
      isClean,
      threatsDetected: threats.length,
      threats: threats.slice(0, 5), // Apenas primeiras 5
      inputLength: input.length,
      outputLength: sanitized.length
    });

    return {
      sanitized,
      isClean,
      threats
    };
  }

  /**
   * Sanitiza objeto recursivamente
   */
  sanitizeObject(obj: any, strict: boolean = false): {
    sanitized: any;
    threatsDetected: number;
  } {
    if (Array.isArray(obj)) {
      let threatsCount = 0;
      const sanitized = obj.map(item => {
        const result = this.sanitizeObject(item, strict);
        threatsCount += result.threatsDetected;
        return result.sanitized;
      });

      return { sanitized, threatsDetected: threatsCount };
    }

    if (typeof obj === 'string') {
      const result = this.sanitize(obj, strict);
      return {
        sanitized: result.sanitized,
        threatsDetected: result.threats.length
      };
    }

    if (typeof obj === 'object' && obj !== null) {
      let threatsCount = 0;
      const sanitized: any = {};

      for (const [key, value] of Object.entries(obj)) {
        // Validar nome da chave
        if (!/^[a-zA-Z0-9_.-]+$/.test(key)) {
          console.warn(`Suspicious key name skipped: ${key}`);
          continue;
        }

        const result = this.sanitizeObject(value, strict);
        sanitized[key] = result.sanitized;
        threatsCount += result.threatsDetected;
      }

      return { sanitized, threatsDetected: threatsCount };
    }

    return { sanitized: obj, threatsDetected: 0 };
  }

  /**
   * Valida se atributo HTML é seguro
   */
  isAttributeSafe(attribute: string, value: string): boolean {
    const UNSAFE_ATTRIBUTES = ['onclick', 'onload', 'onerror', 'onmouseover'];
    const UNSAFE_PROTOCOLS = ['javascript:', 'data:', 'vbscript:'];

    // Verificar nome do atributo
    if (UNSAFE_ATTRIBUTES.some(attr => attribute.toLowerCase().includes(attr))) {
      return false;
    }

    // Verificar valor
    for (const protocol of UNSAFE_PROTOCOLS) {
      if (value.toLowerCase().includes(protocol)) {
        return false;
      }
    }

    return true;
  }

  /**
   * Escape HTML
   */
  escapeHtml(text: string): string {
    const map: Record<string, string> = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };

    return text.replace(/[&<>"']/g, m => map[m]);
  }

  /**
   * Decode HTML entities
   */
  decodeHtml(html: string): string {
    const txt = document.createElement('textarea');
    txt.innerHTML = html;
    return txt.value;
  }

  /**
   * Log de sanitização
   */
  private log(type: string, metadata: any = {}): void {
    this.validationLog.push({
      timestamp: new Date().toISOString(),
      type,
      ...metadata
    });

    // Manter últimos 10000 logs
    if (this.validationLog.length > 10000) {
      this.validationLog = this.validationLog.slice(-10000);
    }
  }

  /**
   * Obter logs
   */
  getLogs(limit: number = 100): any[] {
    return this.validationLog.slice(-limit);
  }

  /**
   * Relatório de segurança XSS
   */
  getReport(): {
    totalSanitizations: number;
    withThreatsDetected: number;
    threatRate: string;
    averageThreatsPerSanitization: string;
  } {
    const withThreats = this.validationLog.filter(
      l => l.threatsDetected && l.threatsDetected > 0
    ).length;

    const totalThreats = this.validationLog.reduce(
      (sum, log) => sum + (log.threatsDetected || 0),
      0
    );

    const total = this.validationLog.length;

    return {
      totalSanitizations: total,
      withThreatsDetected: withThreats,
      threatRate: total > 0
        ? ((withThreats / total) * 100).toFixed(2) + '%'
        : '0%',
      averageThreatsPerSanitization: total > 0
        ? (totalThreats / total).toFixed(2)
        : '0'
    };
  }
}

export default XSSSanitizer;
