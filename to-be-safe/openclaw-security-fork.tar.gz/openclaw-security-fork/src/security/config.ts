import { config } from 'dotenv';

config();

/**
 * Configuração centralizada de segurança para OpenClaw
 * Todos os valores sensíveis vêm de variáveis de ambiente
 */

export const SECURITY_CONFIG = {
  // WebSocket Security (CVE-2026-25253)
  websocket: {
    allowedOrigins: [
      process.env.FRONTEND_URL || 'http://localhost:3000',
      'https://yourdomain.com',
      'https://app.yourdomain.com'
    ],
    tokenTimeout: parseInt(process.env.WS_TOKEN_TIMEOUT || '3600000'), // 1 hora
    maxConnections: parseInt(process.env.WS_MAX_CONNECTIONS || '1000'),
    rateLimitPerIP: parseInt(process.env.WS_RATE_LIMIT || '100')
  },

  // Credentials Security
  credentials: {
    encryptionAlgorithm: 'aes-256-gcm',
    bcryptRounds: 12,
    maxCredentialAge: 90 * 24 * 60 * 60 * 1000, // 90 dias
    encryptionSalt: process.env.ENCRYPTION_SALT || '',
    rotationInterval: 30 * 24 * 60 * 60 * 1000 // 30 dias
  },

  // Web Security (CSRF, XSS, CORS)
  web: {
    corsOrigins: [
      'http://localhost:3000',
      'http://localhost:5173',
      process.env.FRONTEND_URL || 'https://yourdomain.com'
    ],
    csrfProtection: true,
    xssProtection: true,
    secureCookies: process.env.NODE_ENV === 'production',
    sessionTimeout: parseInt(process.env.SESSION_TIMEOUT || '3600000'), // 1 hora
    rateLimitWindowMs: 15 * 60 * 1000, // 15 minutos
    rateLimitMaxRequests: 100
  },

  // Skills Security
  skills: {
    maxMemory: 128 * 1024 * 1024, // 128MB
    maxExecutionTime: 30000, // 30 segundos
    enableSandbox: true,
    requireSignature: true,
    requireManifest: true
  },

  // Prompt Injection Defense
  prompts: {
    maxPromptLength: parseInt(process.env.MAX_PROMPT_LENGTH || '100000'),
    maxTokens: parseInt(process.env.MAX_TOKENS || '10000'),
    strictMode: process.env.NODE_ENV === 'production',
    enableTokenAnalysis: true
  },

  // Admin Security
  admin: {
    requireMFA: true,
    sessionTimeout: 3600000, // 1 hora
    maxFailedAttempts: 5,
    lockoutDuration: 900000, // 15 minutos
    auditAllActions: true,
    ipWhitelistRequired: process.env.NODE_ENV === 'production',
    encryptSensitiveData: true
  }
};

/**
 * Validar configuração crítica no startup
 */
export function validateSecurityConfig(): void {
  const requiredEnvVars = [
    'ENCRYPTION_SALT'
  ];

  const missing = requiredEnvVars.filter(v => !process.env[v]);

  if (missing.length > 0 && process.env.NODE_ENV === 'production') {
    throw new Error(
      `Missing required security configuration: ${missing.join(', ')}`
    );
  }

  console.log('✓ Security configuration validated');
}

export default SECURITY_CONFIG;
