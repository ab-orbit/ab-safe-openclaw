import { v4 as uuidv4 } from 'uuid';

export interface CSRFToken {
  token: string;
  createdAt: number;
  expiresAt: number;
  sessionId: string;
  used: boolean;
}

/**
 * Proteção contra CSRF (Cross-Site Request Forgery)
 * Implementa double-token pattern com expiração
 */
export class CSRFProtection {
  private tokens = new Map<string, CSRFToken>();
  private sessionTokens = new Map<string, Set<string>>();
  private readonly TOKEN_LIFETIME = 3600000; // 1 hora
  private cleanupInterval: NodeJS.Timeout | null = null;
  private validationLog: any[] = [];

  constructor() {
    this.startCleanup();
  }

  /**
   * Gera novo token CSRF
   */
  generateToken(sessionId: string): string {
    const token = uuidv4();
    const csrfToken: CSRFToken = {
      token,
      createdAt: Date.now(),
      expiresAt: Date.now() + this.TOKEN_LIFETIME,
      sessionId,
      used: false
    };

    this.tokens.set(token, csrfToken);

    // Rastrear tokens por sessão
    if (!this.sessionTokens.has(sessionId)) {
      this.sessionTokens.set(sessionId, new Set());
    }
    this.sessionTokens.get(sessionId)!.add(token);

    this.log('token_generated', `Token generated for session ${sessionId}`, {
      sessionId,
      token: token.slice(0, 8) + '...',
      expiresAt: csrfToken.expiresAt
    });

    return token;
  }

  /**
   * Valida token CSRF
   */
  validateToken(token: string, sessionId: string): {
    valid: boolean;
    reason?: string;
  } {
    // Validar existência
    const csrfToken = this.tokens.get(token);
    if (!csrfToken) {
      this.log('validation_failed', 'Token not found', {
        token: token.slice(0, 8) + '...',
        sessionId,
        reason: 'not_found'
      });

      return {
        valid: false,
        reason: 'Token not found'
      };
    }

    // Validar sessão
    if (csrfToken.sessionId !== sessionId) {
      this.log('validation_failed', 'Session mismatch', {
        token: token.slice(0, 8) + '...',
        expectedSession: sessionId,
        tokenSession: csrfToken.sessionId,
        reason: 'session_mismatch'
      });

      return {
        valid: false,
        reason: 'Session mismatch'
      };
    }

    // Validar expiração
    if (Date.now() > csrfToken.expiresAt) {
      this.tokens.delete(token);
      this.log('validation_failed', 'Token expired', {
        token: token.slice(0, 8) + '...',
        sessionId,
        reason: 'expired'
      });

      return {
        valid: false,
        reason: 'Token expired'
      };
    }

    // Validar se já foi usado (single-use tokens)
    if (csrfToken.used) {
      this.log('validation_failed', 'Token already used', {
        token: token.slice(0, 8) + '...',
        sessionId,
        reason: 'already_used'
      });

      return {
        valid: false,
        reason: 'Token already used'
      };
    }

    // Marcar como usado
    csrfToken.used = true;

    this.log('validation_success', 'Token validated', {
      token: token.slice(0, 8) + '...',
      sessionId
    });

    return {
      valid: true
    };
  }

  /**
   * Invalida todos os tokens de uma sessão
   */
  invalidateSessionTokens(sessionId: string): number {
    const tokens = this.sessionTokens.get(sessionId) || new Set();
    let count = 0;

    for (const token of tokens) {
      this.tokens.delete(token);
      count++;
    }

    this.sessionTokens.delete(sessionId);

    this.log('session_invalidated', `Invalidated ${count} tokens for session`, {
      sessionId,
      count
    });

    return count;
  }

  /**
   * Limpeza automática de tokens expirados
   */
  private startCleanup(): void {
    this.cleanupInterval = setInterval(() => {
      const now = Date.now();
      let cleaned = 0;

      for (const [token, data] of this.tokens.entries()) {
        if (data.expiresAt < now) {
          this.tokens.delete(token);

          // Remover da sessão também
          const sessionTokens = this.sessionTokens.get(data.sessionId);
          if (sessionTokens) {
            sessionTokens.delete(token);
          }

          cleaned++;
        }
      }

      if (cleaned > 0) {
        this.log('cleanup', `Cleaned up ${cleaned} expired tokens`, {
          count: cleaned
        });
      }
    }, 300000); // 5 minutos
  }

  /**
   * Para a limpeza automática
   */
  stopCleanup(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
  }

  /**
   * Log de eventos
   */
  private log(type: string, message: string, metadata: any = {}): void {
    this.validationLog.push({
      timestamp: new Date().toISOString(),
      type,
      message,
      ...metadata
    });

    // Manter últimos 10000 logs
    if (this.validationLog.length > 10000) {
      this.validationLog = this.validationLog.slice(-10000);
    }
  }

  /**
   * Obter logs
   */
  getLogs(limit: number = 100): any[] {
    return this.validationLog.slice(-limit);
  }

  /**
   * Estatísticas
   */
  getStatistics(): {
    activeTokens: number;
    activeSessions: number;
    totalValidations: number;
    validationSuccessRate: string;
  } {
    const successful = this.validationLog.filter(l => l.type === 'validation_success').length;
    const total = this.validationLog.filter(
      l => l.type === 'validation_success' || l.type === 'validation_failed'
    ).length;

    return {
      activeTokens: this.tokens.size,
      activeSessions: this.sessionTokens.size,
      totalValidations: total,
      validationSuccessRate: total > 0
        ? ((successful / total) * 100).toFixed(2) + '%'
        : '0%'
    };
  }
}

export default CSRFProtection;
