import keytar from 'keytar';

/**
 * Integração com Keyring do Sistema Operacional
 * Permite armazenar credenciais de forma segura no SO
 */
export class KeyringIntegration {
  private service: string;
  private validationLog: any[] = [];
  private readonly SERVICE_NAME = 'OpenClaw';

  constructor(service: string = 'openclaw') {
    this.service = service;
  }

  /**
   * Verifica se keyring está disponível
   */
  async isAvailable(): Promise<boolean> {
    try {
      // Tentar uma operação simples para verificar disponibilidade
      const testKey = `${this.SERVICE_NAME}-test-${Date.now()}`;
      await keytar.setPassword(this.SERVICE_NAME, testKey, 'test');
      await keytar.deletePassword(this.SERVICE_NAME, testKey);
      return true;
    } catch (error) {
      console.warn('Keyring not available:', (error as any).message);
      return false;
    }
  }

  /**
   * Armazena credencial no keyring
   */
  async storeCredential(
    account: string,
    password: string
  ): Promise<{ success: boolean; error?: string }> {
    try {
      if (!account || !password) {
        return {
          success: false,
          error: 'Account and password required'
        };
      }

      await keytar.setPassword(this.SERVICE_NAME, account, password);

      this.log('store_credential', `Credential stored for ${account}`, {
        account,
        success: true
      });

      return { success: true };
    } catch (error: any) {
      this.log('store_credential', `Failed to store credential for ${account}`, {
        account,
        success: false,
        error: error.message
      });

      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Recupera credencial do keyring
   */
  async retrieveCredential(
    account: string
  ): Promise<{ password?: string; success: boolean; error?: string }> {
    try {
      if (!account) {
        return {
          success: false,
          error: 'Account required'
        };
      }

      const password = await keytar.getPassword(this.SERVICE_NAME, account);

      if (!password) {
        this.log('retrieve_credential', `Credential not found for ${account}`, {
          account,
          success: false
        });

        return {
          success: false,
          error: 'Credential not found'
        };
      }

      this.log('retrieve_credential', `Credential retrieved for ${account}`, {
        account,
        success: true
      });

      return { password, success: true };
    } catch (error: any) {
      this.log('retrieve_credential', `Failed to retrieve credential for ${account}`, {
        account,
        success: false,
        error: error.message
      });

      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Atualiza credencial no keyring
   */
  async updateCredential(
    account: string,
    newPassword: string
  ): Promise<{ success: boolean; error?: string }> {
    try {
      // Remover antiga
      await keytar.deletePassword(this.SERVICE_NAME, account);

      // Armazenar nova
      await keytar.setPassword(this.SERVICE_NAME, account, newPassword);

      this.log('update_credential', `Credential updated for ${account}`, {
        account,
        success: true
      });

      return { success: true };
    } catch (error: any) {
      this.log('update_credential', `Failed to update credential for ${account}`, {
        account,
        success: false,
        error: error.message
      });

      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Deleta credencial do keyring
   */
  async deleteCredential(account: string): Promise<{ success: boolean; error?: string }> {
    try {
      const result = await keytar.deletePassword(this.SERVICE_NAME, account);

      if (result) {
        this.log('delete_credential', `Credential deleted for ${account}`, {
          account,
          success: true
        });

        return { success: true };
      } else {
        this.log('delete_credential', `Credential not found for ${account}`, {
          account,
          success: false
        });

        return {
          success: false,
          error: 'Credential not found'
        };
      }
    } catch (error: any) {
      this.log('delete_credential', `Failed to delete credential for ${account}`, {
        account,
        success: false,
        error: error.message
      });

      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Lista todas as contas armazenadas
   */
  async listCredentials(): Promise<string[]> {
    try {
      const credentials = await keytar.findCredentials(this.SERVICE_NAME);
      return credentials.map(c => c.account);
    } catch (error) {
      console.error('Failed to list credentials:', error);
      return [];
    }
  }

  /**
   * Verifica se conta existe
   */
  async hasCredential(account: string): Promise<boolean> {
    try {
      const password = await keytar.getPassword(this.SERVICE_NAME, account);
      return !!password;
    } catch (error) {
      return false;
    }
  }

  /**
   * Log de operações
   */
  private log(type: string, message: string, metadata: any = {}): void {
    this.validationLog.push({
      timestamp: new Date().toISOString(),
      type,
      message,
      ...metadata
    });

    // Manter últimos 10000 logs
    if (this.validationLog.length > 10000) {
      this.validationLog = this.validationLog.slice(-10000);
    }
  }

  /**
   * Obter logs
   */
  getLogs(limit: number = 100): any[] {
    return this.validationLog.slice(-limit);
  }

  /**
   * Obter relatório
   */
  getReport(): {
    totalOperations: number;
    successfulOperations: number;
    failedOperations: number;
    successRate: string;
    logCount: number;
  } {
    const successful = this.validationLog.filter(l => l.success).length;
    const failed = this.validationLog.filter(l => !l.success).length;
    const total = this.validationLog.length;

    return {
      totalOperations: total,
      successfulOperations: successful,
      failedOperations: failed,
      successRate: total > 0 ? ((successful / total) * 100).toFixed(2) + '%' : '0%',
      logCount: this.validationLog.length
    };
  }
}

export default KeyringIntegration;
