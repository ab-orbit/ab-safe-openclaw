import { describe, it, expect, beforeEach } from '@jest/globals';
import { WebSocketSecurityManager, extractTokenFromRequest } from '../../src/security/websocket/secure-websocket-manager';
import { OriginValidator } from '../../src/security/websocket/origin-validator';
import { RateLimiter } from '../../src/security/websocket/rate-limiter';

describe('WebSocket Security Tests', () => {
  let manager: WebSocketSecurityManager;
  let validator: OriginValidator;
  let limiter: RateLimiter;

  beforeEach(() => {
    manager = new WebSocketSecurityManager({
      allowedOrigins: ['http://localhost:3000', 'https://yourdomain.com'],
      tokenTimeout: 3600000,
      maxConnections: 1000,
      rateLimitPerIP: 100
    });

    validator = new OriginValidator(['http://localhost:3000', 'https://yourdomain.com']);
    limiter = new RateLimiter({
      windowMs: 60000,
      maxRequestsPerIP: 100,
      maxRequestsPerUser: 50,
      maxRequestsGlobal: 10000
    });
  });

  describe('Origin Validation', () => {
    it('should validate allowed origin', () => {
      const mockReq = {
        headers: {
          origin: 'http://localhost:3000'
        },
        ip: '127.0.0.1',
        get: (header: string) => 'test-agent'
      } as any;

      const result = manager.validateOrigin(mockReq, '127.0.0.1');
      expect(result.valid).toBe(true);
    });

    it('should reject unauthorized origin', () => {
      const mockReq = {
        headers: {
          origin: 'http://malicious-site.com'
        },
        ip: '127.0.0.1',
        get: (header: string) => 'test-agent'
      } as any;

      const result = manager.validateOrigin(mockReq, '127.0.0.1');
      expect(result.valid).toBe(false);
      expect(result.reason).toContain('not in whitelist');
    });

    it('should reject missing origin', () => {
      const mockReq = {
        headers: {},
        ip: '127.0.0.1',
        get: (header: string) => 'test-agent'
      } as any;

      const result = manager.validateOrigin(mockReq, '127.0.0.1');
      expect(result.valid).toBe(false);
    });
  });

  describe('Token Validation', () => {
    const validToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test.signature';

    it('should accept valid token', () => {
      const result = manager.validateAndStoreToken(
        validToken,
        '127.0.0.1',
        'test-agent',
        ['operator.admin']
      );

      expect(result.valid).toBe(true);
    });

    it('should reject invalid token format', () => {
      const result = manager.validateAndStoreToken(
        'invalid-token',
        '127.0.0.1',
        'test-agent',
        ['operator.admin']
      );

      expect(result.valid).toBe(false);
      expect(result.reason).toContain('Invalid token format');
    });

    it('should detect expired tokens', (done) => {
      const config = {
        allowedOrigins: ['http://localhost:3000'],
        tokenTimeout: 100, // 100ms
        maxConnections: 1000,
        rateLimitPerIP: 100
      };

      const shortManager = new WebSocketSecurityManager(config);
      const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test.sig';

      shortManager.validateAndStoreToken(
        token,
        '127.0.0.1',
        'test-agent',
        ['operator.admin']
      );

      expect(shortManager.isTokenExpired(token)).toBe(false);

      setTimeout(() => {
        expect(shortManager.isTokenExpired(token)).toBe(true);
        shortManager.stopCleanup();
        done();
      }, 150);
    });

    it('should revoke tokens', () => {
      const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test.sig';

      manager.validateAndStoreToken(
        token,
        '127.0.0.1',
        'test-agent',
        ['operator.admin']
      );

      manager.revokeToken(token);

      const result = manager.validateAndStoreToken(
        token,
        '127.0.0.1',
        'test-agent',
        ['operator.admin']
      );

      expect(result.valid).toBe(false);
      expect(result.reason).toContain('revoked');
    });
  });

  describe('Rate Limiting', () => {
    it('should allow requests within limit', () => {
      for (let i = 0; i < 50; i++) {
        const result = limiter.checkLimit('192.168.1.100');
        expect(result.allowed).toBe(true);
      }
    });

    it('should block requests exceeding limit', () => {
      for (let i = 0; i < 100; i++) {
        limiter.checkLimit('192.168.1.100');
      }

      const result = limiter.checkLimit('192.168.1.100');
      expect(result.allowed).toBe(false);
    });

    it('should block IPs after multiple violations', () => {
      const config = {
        windowMs: 60000,
        maxRequestsPerIP: 5,
        maxRequestsPerUser: 50,
        maxRequestsGlobal: 10000
      };

      const testLimiter = new RateLimiter(config);

      for (let i = 0; i < 15; i++) {
        testLimiter.checkLimit('192.168.1.100');
      }

      const blockedIPs = testLimiter.getBlockedIPs();
      expect(blockedIPs).toContain('192.168.1.100');
    });
  });

  describe('Origin Validator', () => {
    it('should add and remove origins', () => {
      expect(validator.getAllowedOrigins()).toContain('http://localhost:3000');

      validator.addOrigin('https://new-domain.com');
      expect(validator.getAllowedOrigins()).toContain('https://new-domain.com');

      validator.removeOrigin('https://new-domain.com');
      expect(validator.getAllowedOrigins()).not.toContain('https://new-domain.com');
    });

    it('should generate validation report', () => {
      const report = validator.getReport();

      expect(report).toHaveProperty('whitelistedOrigins');
      expect(report.whitelistedOrigins).toBeGreaterThan(0);
    });
  });

  describe('Statistics', () => {
    it('should collect statistics', () => {
      const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test.sig';

      manager.validateAndStoreToken(
        token,
        '127.0.0.1',
        'test-agent',
        ['operator.admin']
      );

      const stats = manager.getStatistics();

      expect(stats.activeTokens).toBeGreaterThan(0);
      expect(stats).toHaveProperty('blockedTokens');
      expect(stats).toHaveProperty('connectionsByIP');
    });
  });
});
