/**
 * Index centralizado de segurança do OpenClaw
 * Exporta todos os módulos de segurança
 */

// WebSocket Security
export { WebSocketSecurityManager, extractTokenFromRequest, setupSecureWebSocketServer } from './websocket/secure-websocket-manager';
export { OriginValidator } from './websocket/origin-validator';
export { RateLimiter } from './websocket/rate-limiter';

// Credentials Security
export { SecureCredentialStore } from './credentials/secure-store';
export { CredentialEncryption } from './credentials/encryption';
export { KeyringIntegration } from './credentials/keyring-integration';

// Web Security
export { CSRFProtection } from './web/csrf-protection';
export { XSSSanitizer } from './web/xss-sanitizer';
export { CORSManager } from './web/cors-manager';
export { SecurityHeaders } from './web/security-headers';

// Skills Security
export { SkillValidator } from './skills/skill-validator';
export { SignatureVerifier } from './skills/signature-verifier';

// Prompt Injection Defense
export { PromptInjectionDetector } from './prompts/injection-detector';

// Configuration
export { SECURITY_CONFIG, validateSecurityConfig } from './config';

/**
 * Factory para criar instâncias de segurança
 */
export class SecurityFactory {
  static createWebSocketManager(config: any) {
    return new (require('./websocket/secure-websocket-manager').WebSocketSecurityManager)(config);
  }

  static createOriginValidator(origins: string[]) {
    return new (require('./websocket/origin-validator').OriginValidator)(origins);
  }

  static createRateLimiter(config: any) {
    return new (require('./websocket/rate-limiter').RateLimiter)(config);
  }

  static createCredentialStore() {
    return new (require('./credentials/secure-store').SecureCredentialStore)();
  }

  static createEncryption() {
    return new (require('./credentials/encryption').CredentialEncryption)();
  }

  static createKeyringIntegration() {
    return new (require('./credentials/keyring-integration').KeyringIntegration)();
  }

  static createCSRFProtection() {
    return new (require('./web/csrf-protection').CSRFProtection)();
  }

  static createXSSSanitizer() {
    return new (require('./web/xss-sanitizer').XSSSanitizer)();
  }

  static createCORSManager(config: any) {
    return new (require('./web/cors-manager').CORSManager)(config);
  }

  static createSecurityHeaders(config: any) {
    return new (require('./web/security-headers').SecurityHeaders)(config);
  }

  static createSkillValidator() {
    return new (require('./skills/skill-validator').SkillValidator)();
  }

  static createSignatureVerifier() {
    return new (require('./skills/signature-verifier').SignatureVerifier)();
  }

  static createPromptInjectionDetector() {
    return new (require('./prompts/injection-detector').PromptInjectionDetector)();
  }
}

export default SecurityFactory;
