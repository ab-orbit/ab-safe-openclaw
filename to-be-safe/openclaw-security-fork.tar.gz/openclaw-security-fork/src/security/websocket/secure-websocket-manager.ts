import { WebSocketServer, WebSocket } from 'ws';
import { Request } from 'express';
import { createHash } from 'crypto';
import { URL } from 'url';

export interface WebSocketSecurityConfig {
  allowedOrigins: string[];
  tokenTimeout: number;
  maxConnections: number;
  rateLimitPerIP: number;
}

export interface TokenMetadata {
  createdAt: number;
  clientIp: string;
  userAgent: string;
  scope: string[];
}

/**
 * Gerenciador de segurança para WebSocket
 * Implementa validação de origem, autenticação de token e rate limiting
 */
export class WebSocketSecurityManager {
  private config: WebSocketSecurityConfig;
  private tokenMetadata = new Map<string, TokenMetadata>();
  private connectionsByIP = new Map<string, number>();
  private blockedTokens = new Set<string>();
  private cleanupInterval: NodeJS.Timeout | null = null;

  constructor(config: WebSocketSecurityConfig) {
    this.config = config;
    this.startTokenCleanup();
  }

  /**
   * Valida a origem da requisição WebSocket
   * Implementa CORS para WebSocket
   */
  validateOrigin(
    req: Request,
    remoteAddress: string
  ): { valid: boolean; reason?: string } {
    const origin = req.headers.origin;
    const referer = req.headers.referer;

    // Rejeita se não houver origem
    if (!origin && !referer) {
      return {
        valid: false,
        reason: 'Missing Origin/Referer header'
      };
    }

    try {
      const originUrl = new URL(origin || referer || '');
      const isAllowed = this.config.allowedOrigins.some(allowed => {
        if (allowed === '*') return true;
        return originUrl.origin === allowed;
      });

      if (!isAllowed) {
        return {
          valid: false,
          reason: `Origin ${origin} not in whitelist`
        };
      }

      return { valid: true };
    } catch (error) {
      return {
        valid: false,
        reason: 'Invalid Origin/Referer format'
      };
    }
  }

  /**
   * Valida e armazena metadata do token
   */
  validateAndStoreToken(
    token: string,
    clientIp: string,
    userAgent: string,
    requiredScopes: string[]
  ): { valid: boolean; reason?: string } {
    // Verifica se token está bloqueado
    if (this.blockedTokens.has(token)) {
      return {
        valid: false,
        reason: 'Token has been revoked'
      };
    }

    // Verifica taxa de conexão por IP
    const currentConnections = this.connectionsByIP.get(clientIp) || 0;
    if (currentConnections >= this.config.rateLimitPerIP) {
      return {
        valid: false,
        reason: 'Rate limit exceeded for this IP'
      };
    }

    // Validação básica do token
    if (!this.isValidTokenFormat(token)) {
      return {
        valid: false,
        reason: 'Invalid token format'
      };
    }

    // Armazena metadata do token
    const metadata: TokenMetadata = {
      createdAt: Date.now(),
      clientIp,
      userAgent,
      scope: requiredScopes
    };

    this.tokenMetadata.set(token, metadata);
    this.connectionsByIP.set(clientIp, currentConnections + 1);

    return { valid: true };
  }

  /**
   * Verifica se token expirou
   */
  isTokenExpired(token: string): boolean {
    const metadata = this.tokenMetadata.get(token);
    if (!metadata) return true;

    const age = Date.now() - metadata.createdAt;
    return age > this.config.tokenTimeout;
  }

  /**
   * Revoga um token
   */
  revokeToken(token: string): void {
    this.blockedTokens.add(token);
    this.tokenMetadata.delete(token);
  }

  /**
   * Limpeza automática de tokens expirados
   */
  private startTokenCleanup(): void {
    this.cleanupInterval = setInterval(() => {
      for (const [token, metadata] of this.tokenMetadata.entries()) {
        if (Date.now() - metadata.createdAt > this.config.tokenTimeout) {
          this.tokenMetadata.delete(token);
          this.blockedTokens.delete(token);
        }
      }
    }, 60000); // A cada minuto
  }

  /**
   * Validação básica do formato do token (JWT)
   */
  private isValidTokenFormat(token: string): boolean {
    return token.length > 20 && token.split('.').length === 3;
  }

  /**
   * Para a limpeza automática
   */
  stopCleanup(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
  }

  /**
   * Obter estatísticas de conexão
   */
  getStatistics(): {
    activeTokens: number;
    activeConnections: number;
    blockedTokens: number;
    connectionsByIP: Record<string, number>;
  } {
    return {
      activeTokens: this.tokenMetadata.size,
      activeConnections: Array.from(this.connectionsByIP.values()).reduce((a, b) => a + b, 0),
      blockedTokens: this.blockedTokens.size,
      connectionsByIP: Object.fromEntries(this.connectionsByIP)
    };
  }
}

/**
 * Extrai token de forma segura da requisição
 */
export function extractTokenFromRequest(req: Request): string | null {
  // 1. Tenta Authorization header
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7);
  }

  // 2. Tenta cookie seguro
  const cookies = req.headers.cookie;
  if (cookies) {
    const match = cookies.match(/auth_token=([^;]+)/);
    if (match) {
      return match[1];
    }
  }

  // NÃO tira token de query parameters (vulnerável)
  return null;
}

/**
 * Handler seguro para mensagens WebSocket
 */
export function handleSecureWebSocketMessage(
  ws: WebSocket,
  message: any,
  token: string,
  manager: WebSocketSecurityManager
): void {
  // Valida estrutura da mensagem
  if (!message.type || !message.id) {
    ws.send(JSON.stringify({ error: 'Invalid message structure' }));
    return;
  }

  // Log da ação
  console.log(`[${token.slice(0, 8)}...] Action: ${message.type}`);

  // Processamento normal
  ws.send(JSON.stringify({
    id: message.id,
    type: 'ack',
    status: 'received'
  }));
}

/**
 * Inicialização segura de WebSocket Server
 */
export function setupSecureWebSocketServer(
  httpServer: any,
  securityConfig: WebSocketSecurityConfig
) {
  const securityManager = new WebSocketSecurityManager(securityConfig);

  const wss = new WebSocketServer({
    noServer: true,
    perMessageDeflate: {
      zlevel: 7,
      memLevel: 7,
      chunkSize: 10 * 1024
    }
  });

  // Validação de upgrade
  httpServer.on('upgrade', (req: Request, socket: any, head: any) => {
    // 1. Validar origem
    const originCheck = securityManager.validateOrigin(req, socket.remoteAddress);
    if (!originCheck.valid) {
      console.warn(`WebSocket connection rejected: ${originCheck.reason}`);
      socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
      socket.destroy();
      return;
    }

    // 2. Extrair e validar token
    const token = extractTokenFromRequest(req);
    if (!token) {
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
      socket.destroy();
      return;
    }

    // 3. Validar token e metadata
    const tokenCheck = securityManager.validateAndStoreToken(
      token,
      socket.remoteAddress,
      req.headers['user-agent'] || 'unknown',
      ['operator.admin']
    );

    if (!tokenCheck.valid) {
      console.warn(`Token validation failed: ${tokenCheck.reason}`);
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
      socket.destroy();
      return;
    }

    // 4. Prosseguir com upgrade
    wss.handleUpgrade(req, socket, head, (ws: WebSocket) => {
      wss.emit('connection', ws, req, token, securityManager);
    });
  });

  // Handler de conexão
  wss.on('connection', (ws: WebSocket, req: Request, token: string, manager: WebSocketSecurityManager) => {
    console.log(`WebSocket connected from ${req.socket.remoteAddress}`);

    // Validar expiração de token em cada mensagem
    ws.on('message', (data: Buffer) => {
      if (manager.isTokenExpired(token)) {
        manager.revokeToken(token);
        ws.close(1008, 'Token expired');
        return;
      }

      try {
        const message = JSON.parse(data.toString());
        handleSecureWebSocketMessage(ws, message, token, manager);
      } catch (error) {
        console.error('Invalid WebSocket message format:', error);
        ws.send(JSON.stringify({ error: 'Invalid message format' }));
      }
    });

    ws.on('close', () => {
      manager.revokeToken(token);
      console.log(`WebSocket closed`);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      manager.revokeToken(token);
    });
  });

  return wss;
}

export default WebSocketSecurityManager;
