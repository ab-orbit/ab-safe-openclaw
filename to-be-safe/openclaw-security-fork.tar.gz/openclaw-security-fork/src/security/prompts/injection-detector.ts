import { EventEmitter } from 'events';

export interface ValidationResult {
  valid: boolean;
  sanitized: string;
  riskLevel: 'safe' | 'warning' | 'critical';
  issues: Array<{
    type: string;
    severity: 'low' | 'medium' | 'high' | 'critical';
    description: string;
    matched: string;
  }>;
  metadata: {
    originalLength: number;
    sanitizedLength: number;
    tokensDetected: string[];
    injectionPatternFound: boolean;
    timeToValidate: number;
  };
}

/**
 * Detector de Injeção de Prompt
 * Identifica tentativas de jailbreak e prompt injection
 */
export class PromptInjectionDetector extends EventEmitter {
  private validationLog: any[] = [];

  // Padrões perigosos de injection
  private injectionPatterns = [
    // Tentativas de sobrescrever instruções
    /ignore\s+(?:your\s+)?previous\s+instructions?/gi,
    /forget\s+(?:all\s+)?previous\s+(?:prompts?|instructions?)/gi,
    /start\s+over/gi,
    /new\s+conversation/gi,
    /reset\s+(?:your\s+)?instructions?/gi,

    // Tentativas de executar comandos
    /execute\s+(?:code|command|shell)/gi,
    /run\s+(?:this\s+)?(?:code|script|command)/gi,
    /eval\s*\(/gi,
    /system\s*\(/gi,

    // Tentativas de roleplay/jailbreak
    /you\s+are\s+(?:now\s+)?an?\s+(?:unrestricted|unsafe|evil)/gi,
    /act\s+as\s+(?:if\s+)?you\s+are/gi,
    /pretend\s+you\s+are/gi,
    /roleplay\s+as/gi,

    // Tentativas de vazamento de dados
    /(?:show|print|output|return)\s+(?:your\s+)?(?:system\s+)?prompt/gi,
    /what\s+(?:are|is)\s+your\s+(?:actual\s+)?instructions?/gi,
    /(?:display|reveal|expose)\s+(?:the\s+)?(?:original\s+)?instructions?/gi,
    /tell\s+me\s+(?:your\s+)?(?:real\s+)?(?:instructions?|rules)/gi
  ];

  // Padrões suspeitos
  private suspiciousPatterns = [
    /(?:password|secret|api[_-]?key|token|credential)/gi,
    /(?:database|sql|query)/gi,
    /(?:admin|root|sudo)/gi,
    /(?:delete|drop|truncate)\s+(?:table|database)/gi
  ];

  /**
   * Valida e sanitiza prompt
   */
  validatePrompt(prompt: string): ValidationResult {
    const startTime = Date.now();

    if (typeof prompt !== 'string') {
      return {
        valid: false,
        sanitized: '',
        riskLevel: 'critical',
        issues: [
          {
            type: 'type_error',
            severity: 'critical',
            description: 'Prompt must be a string',
            matched: typeof prompt
          }
        ],
        metadata: {
          originalLength: 0,
          sanitizedLength: 0,
          tokensDetected: [],
          injectionPatternFound: false,
          timeToValidate: Date.now() - startTime
        }
      };
    }

    const issues: ValidationResult['issues'] = [];
    let riskLevel: 'safe' | 'warning' | 'critical' = 'safe';
    let sanitized = prompt;

    // 1. Validar comprimento
    const MAX_LENGTH = 100000;
    if (prompt.length > MAX_LENGTH) {
      issues.push({
        type: 'exceeds_max_length',
        severity: 'high',
        description: `Prompt exceeds maximum length of ${MAX_LENGTH}`,
        matched: prompt.slice(0, 100) + '...'
      });
      riskLevel = 'warning';
      sanitized = prompt.slice(0, MAX_LENGTH);
    }

    // 2. Detectar padrões de injection
    const injectionMatches = this.detectInjectionPatterns(prompt);
    if (injectionMatches.length > 0) {
      issues.push(...injectionMatches);
      riskLevel = 'critical';
    }

    // 3. Detectar padrões suspeitos
    const suspiciousMatches = this.detectSuspiciousPatterns(prompt);
    if (suspiciousMatches.length > 0) {
      issues.push(...suspiciousMatches);
      if (riskLevel !== 'critical') riskLevel = 'warning';
    }

    // 4. Análise de tokens
    const tokensDetected = this.analyzeTokens(prompt);

    // 5. Sanitizar prompt
    sanitized = this.sanitizePrompt(sanitized);

    const result: ValidationResult = {
      valid: riskLevel !== 'critical',
      sanitized,
      riskLevel,
      issues,
      metadata: {
        originalLength: prompt.length,
        sanitizedLength: sanitized.length,
        tokensDetected,
        injectionPatternFound: injectionMatches.length > 0,
        timeToValidate: Date.now() - startTime
      }
    };

    // Log da validação
    this.logValidation(prompt, result);

    return result;
  }

  /**
   * Detecta padrões de injection
   */
  private detectInjectionPatterns(prompt: string): ValidationResult['issues'] {
    const issues: ValidationResult['issues'] = [];

    for (const pattern of this.injectionPatterns) {
      const matches = prompt.match(pattern);
      if (matches) {
        issues.push({
          type: 'injection_pattern_detected',
          severity: 'high',
          description: `Injection pattern detected: ${pattern.source}`,
          matched: matches[0]
        });
      }
    }

    return issues;
  }

  /**
   * Detecta padrões suspeitos
   */
  private detectSuspiciousPatterns(prompt: string): ValidationResult['issues'] {
    const issues: ValidationResult['issues'] = [];

    for (const pattern of this.suspiciousPatterns) {
      const matches = prompt.match(pattern);
      if (matches) {
        issues.push({
          type: 'suspicious_pattern',
          severity: 'medium',
          description: `Suspicious pattern detected: ${pattern.source}`,
          matched: matches[0]
        });
      }
    }

    return issues;
  }

  /**
   * Analisa tokens do prompt
   */
  private analyzeTokens(prompt: string): string[] {
    const detectedTokens: string[] = [];

    // Detectar variáveis template
    const varMatches = prompt.match(/\$\{[^}]+\}|\{\{[^}]+\}\}/g);
    if (varMatches) {
      detectedTokens.push(...varMatches.map(m => `variable: ${m}`));
    }

    // Detectar tags especiais
    const tagMatches = prompt.match(/\[([A-Z_]+)\]/g);
    if (tagMatches) {
      detectedTokens.push(...tagMatches.map(m => `tag: ${m}`));
    }

    // Detectar URLs
    const urlMatches = prompt.match(/https?:\/\/[^\s]+/g);
    if (urlMatches) {
      detectedTokens.push(...urlMatches.map(m => `url: ${m}`));
    }

    return detectedTokens;
  }

  /**
   * Sanitiza prompt
   */
  private sanitizePrompt(prompt: string): string {
    let sanitized = prompt;

    // 1. Remover caracteres de controle
    sanitized = sanitized.replace(/[\x00-\x1F\x7F]/g, '');

    // 2. Remover tentativas de escape
    sanitized = sanitized.replace(/\\x[0-9a-f]{2}/gi, '');
    sanitized = sanitized.replace(/\\u[0-9a-f]{4}/gi, '');

    // 3. Remover sequências perigosas de template
    sanitized = sanitized.replace(/\{\{[^}]+\}\}/g, '{BLOCKED}');
    sanitized = sanitized.replace(/\$\{[^}]+\}/g, '{BLOCKED}');

    // 4. Limitar espaços em branco
    sanitized = sanitized.replace(/\s{2,}/g, ' ');

    // 5. Remover tags perigosas
    sanitized = sanitized.replace(/\[SYSTEM\]/gi, '');
    sanitized = sanitized.replace(/\[INSTRUCTION\]/gi, '');
    sanitized = sanitized.replace(/\[PROMPT\]/gi, '');

    return sanitized.trim();
  }

  /**
   * Sanitiza output de LLM
   */
  sanitizeOutput(output: string): string {
    let sanitized = output;

    // Remover blocos de código
    sanitized = sanitized.replace(/```[\s\S]*?```/g, '[CODE_BLOCK_REMOVED]');

    // Remover scripts
    sanitized = sanitized.replace(/<script[\s\S]*?<\/script>/gi, '[SCRIPT_REMOVED]');

    // Remover comandos shell perigosos
    sanitized = sanitized.replace(/(?:rm|rm -rf|dd|mkfs|mkfs\.ext4)\s+/gi, '[COMMAND_BLOCKED]');

    return sanitized;
  }

  /**
   * Log de validação
   */
  private logValidation(prompt: string, result: ValidationResult): void {
    this.validationLog.push({
      timestamp: Date.now(),
      promptLength: prompt.length,
      valid: result.valid,
      riskLevel: result.riskLevel,
      issueCount: result.issues.length,
      injectionFound: result.metadata.injectionPatternFound,
      validationTime: result.metadata.timeToValidate
    });

    // Emitir evento se problema detectado
    if (!result.valid) {
      this.emit('injection_detected', {
        prompt: prompt.slice(0, 200),
        issues: result.issues
      });
    }

    // Manter últimos 10000 logs
    if (this.validationLog.length > 10000) {
      this.validationLog = this.validationLog.slice(-10000);
    }
  }

  /**
   * Obter logs
   */
  getLogs(limit: number = 100): any[] {
    return this.validationLog.slice(-limit);
  }

  /**
   * Relatório
   */
  getReport(): {
    totalValidations: number;
    injectionAttempts: number;
    attackRate: string;
    avgValidationTime: string;
  } {
    const suspicious = this.validationLog.filter(log => !log.valid);

    return {
      totalValidations: this.validationLog.length,
      injectionAttempts: suspicious.length,
      attackRate: this.validationLog.length > 0
        ? ((suspicious.length / this.validationLog.length) * 100).toFixed(2) + '%'
        : '0%',
      avgValidationTime: this.validationLog.length > 0
        ? (this.validationLog.reduce((sum, log) => sum + log.validationTime, 0) / this.validationLog.length).toFixed(2) + 'ms'
        : '0ms'
    };
  }
}

export default PromptInjectionDetector;
