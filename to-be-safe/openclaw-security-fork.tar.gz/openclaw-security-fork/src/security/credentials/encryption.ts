import crypto from 'crypto';

/**
 * Gerenciador de criptografia para credenciais
 * Implementa AES-256-GCM com validação de integridade
 */
export class CredentialEncryption {
  private readonly ALGORITHM = 'aes-256-gcm';
  private readonly IV_LENGTH = 16;
  private readonly SALT_LENGTH = 16;
  private readonly TAG_LENGTH = 16;
  private masterKey: Buffer | null = null;
  private derivedKeys = new Map<string, Buffer>();

  /**
   * Inicializa com master key
   */
  initialize(masterKey: string | Buffer): void {
    if (typeof masterKey === 'string') {
      if (masterKey.length < 32) {
        throw new Error('Master key must be at least 32 characters');
      }
      this.masterKey = Buffer.from(masterKey);
    } else {
      if (masterKey.length < 32) {
        throw new Error('Master key must be at least 32 bytes');
      }
      this.masterKey = masterKey;
    }

    console.log('✓ Encryption initialized');
  }

  /**
   * Derivas chave específica a partir da master key
   */
  private deriveKey(salt: string, iterations: number = 100000): Buffer {
    if (!this.masterKey) {
      throw new Error('Master key not initialized');
    }

    const cacheKey = `${salt}:${iterations}`;
    if (this.derivedKeys.has(cacheKey)) {
      return this.derivedKeys.get(cacheKey)!;
    }

    const key = crypto.pbkdf2Sync(
      this.masterKey,
      salt,
      iterations,
      32,
      'sha256'
    );

    this.derivedKeys.set(cacheKey, key);
    return key;
  }

  /**
   * Criptografa um valor
   */
  encrypt(
    plaintext: string,
    salt?: string
  ): {
    ciphertext: string;
    iv: string;
    tag: string;
    salt: string;
    algorithm: string;
  } {
    if (!this.masterKey) {
      throw new Error('Master key not initialized');
    }

    // Gerar salt e IV
    const saltValue = salt || crypto.randomBytes(this.SALT_LENGTH).toString('hex');
    const iv = crypto.randomBytes(this.IV_LENGTH);

    // Derivar chave
    const key = this.deriveKey(saltValue);

    // Criar cipher
    const cipher = crypto.createCipheriv(this.ALGORITHM, key, iv);

    // Criptografar
    let encrypted = cipher.update(plaintext, 'utf-8', 'hex');
    encrypted += cipher.final('hex');

    // Obter tag de autenticação
    const tag = (cipher as any).getAuthTag();

    return {
      ciphertext: encrypted,
      iv: iv.toString('hex'),
      tag: tag.toString('hex'),
      salt: saltValue,
      algorithm: this.ALGORITHM
    };
  }

  /**
   * Descriptografa um valor
   */
  decrypt(
    ciphertext: string,
    iv: string,
    tag: string,
    salt: string
  ): string {
    if (!this.masterKey) {
      throw new Error('Master key not initialized');
    }

    // Derivar chave
    const key = this.deriveKey(salt);

    // Criar decipher
    const decipher = crypto.createDecipheriv(
      this.ALGORITHM,
      key,
      Buffer.from(iv, 'hex')
    );

    // Definir tag de autenticação
    (decipher as any).setAuthTag(Buffer.from(tag, 'hex'));

    // Descriptografar
    let decrypted = decipher.update(ciphertext, 'hex', 'utf-8');
    decrypted += decipher.final('utf-8');

    return decrypted;
  }

  /**
   * Valida integridade sem descriptografar
   */
  validateIntegrity(
    ciphertext: string,
    iv: string,
    tag: string,
    salt: string
  ): boolean {
    try {
      if (!this.masterKey) {
        return false;
      }

      const key = this.deriveKey(salt);

      // Tentar apenas validar a tag
      const decipher = crypto.createDecipheriv(
        this.ALGORITHM,
        key,
        Buffer.from(iv, 'hex')
      );

      (decipher as any).setAuthTag(Buffer.from(tag, 'hex'));

      // Tentar descriptografar um byte para validar tag
      decipher.update(ciphertext.slice(0, 2), 'hex', 'utf-8');

      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * Realiza re-criptografia com nova chave
   * Útil para rotação de chaves
   */
  reencrypt(
    ciphertext: string,
    iv: string,
    tag: string,
    oldSalt: string,
    newSalt: string
  ): {
    ciphertext: string;
    iv: string;
    tag: string;
    salt: string;
  } {
    // Descriptografar com chave antiga
    const plaintext = this.decrypt(ciphertext, iv, tag, oldSalt);

    // Criptografar com chave nova
    return this.encrypt(plaintext, newSalt);
  }

  /**
   * Gera nova salt
   */
  generateSalt(): string {
    return crypto.randomBytes(this.SALT_LENGTH).toString('hex');
  }

  /**
   * Comparação segura de valores (contra timing attacks)
   */
  timingSafeCompare(a: string, b: string): boolean {
    return crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
  }

  /**
   * Hash HMAC de um valor (para verificação)
   */
  hmac(value: string, key?: string): string {
    const hmacKey = key || this.masterKey;
    if (!hmacKey) {
      throw new Error('Master key or HMAC key not provided');
    }

    const hmac = crypto.createHmac('sha256', hmacKey);
    hmac.update(value);
    return hmac.digest('hex');
  }

  /**
   * Gera hash seguro
   */
  hash(value: string): string {
    return crypto.createHash('sha256').update(value).digest('hex');
  }

  /**
   * Obter estatísticas
   */
  getStatistics(): {
    cachedKeys: number;
    algorithm: string;
    ivLength: number;
    saltLength: number;
    tagLength: number;
  } {
    return {
      cachedKeys: this.derivedKeys.size,
      algorithm: this.ALGORITHM,
      ivLength: this.IV_LENGTH,
      saltLength: this.SALT_LENGTH,
      tagLength: this.TAG_LENGTH
    };
  }

  /**
   * Limpar cache de chaves derivadas
   */
  clearKeyCache(): void {
    this.derivedKeys.clear();
    console.log('✓ Key cache cleared');
  }
}

export default CredentialEncryption;
