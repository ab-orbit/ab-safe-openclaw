import { createHash } from 'crypto';
import Ajv from 'ajv';

export interface SkillManifest {
  name: string;
  version: string;
  author: string;
  description?: string;
  permissions: string[];
  hash: string;
  signature: string;
  requiredCapabilities?: string[];
}

const SKILL_MANIFEST_SCHEMA = {
  type: 'object',
  required: ['name', 'version', 'author', 'permissions', 'hash', 'signature'],
  properties: {
    name: { type: 'string', minLength: 1, maxLength: 100 },
    version: { type: 'string', pattern: '^\\d+\\.\\d+\\.\\d+$' },
    author: { type: 'string', minLength: 1 },
    description: { type: 'string', maxLength: 500 },
    permissions: {
      type: 'array',
      items: {
        type: 'string',
        enum: [
          'fs:read',
          'fs:write',
          'network:request',
          'env:read',
          'process:execute',
          'db:read',
          'db:write',
          'cache:read',
          'cache:write'
        ]
      }
    },
    hash: { type: 'string', pattern: '^[a-f0-9]{64}$' },
    signature: { type: 'string' },
    requiredCapabilities: { type: 'array', items: { type: 'string' } }
  }
};

/**
 * Validador de Skills
 * Valida manifesto, hash e assinatura
 */
export class SkillValidator {
  private validator: any;
  private validateManifest: any;
  private validationLog: any[] = [];

  constructor() {
    this.validator = new Ajv();
    this.validateManifest = this.validator.compile(SKILL_MANIFEST_SCHEMA);
  }

  /**
   * Valida hash do skill
   */
  validateHash(skillCode: string, expectedHash: string): {
    valid: boolean;
    calculatedHash?: string;
    reason?: string;
  } {
    try {
      const calculated = createHash('sha256')
        .update(skillCode)
        .digest('hex');

      const valid = calculated === expectedHash;

      this.log('hash_validation', {
        valid,
        expectedHash: expectedHash.slice(0, 8) + '...',
        calculatedHash: calculated.slice(0, 8) + '...'
      });

      if (!valid) {
        return {
          valid: false,
          calculatedHash: calculated,
          reason: 'Hash mismatch'
        };
      }

      return { valid: true, calculatedHash: calculated };
    } catch (error: any) {
      this.log('hash_validation', {
        valid: false,
        error: error.message
      });

      return {
        valid: false,
        reason: error.message
      };
    }
  }

  /**
   * Valida assinatura do skill
   */
  validateSignature(
    skillCode: string,
    signature: string,
    authorPublicKey: string
  ): {
    valid: boolean;
    reason?: string;
  } {
    try {
      const crypto = require('crypto');
      const verifier = crypto.createVerify('sha256');
      verifier.update(skillCode);

      const isValid = verifier.verify(authorPublicKey, Buffer.from(signature, 'hex'));

      this.log('signature_validation', {
        valid: isValid,
        signature: signature.slice(0, 8) + '...'
      });

      if (!isValid) {
        return {
          valid: false,
          reason: 'Signature verification failed'
        };
      }

      return { valid: true };
    } catch (error: any) {
      this.log('signature_validation', {
        valid: false,
        error: error.message
      });

      return {
        valid: false,
        reason: error.message
      };
    }
  }

  /**
   * Valida manifesto
   */
  validateManifestStructure(manifest: any): {
    valid: boolean;
    errors?: any[];
  } {
    const isValid = this.validateManifest(manifest);

    if (!isValid) {
      this.log('manifest_validation', {
        valid: false,
        errors: this.validateManifest.errors
      });

      return {
        valid: false,
        errors: this.validateManifest.errors
      };
    }

    this.log('manifest_validation', {
      valid: true,
      skillName: manifest.name,
      skillVersion: manifest.version
    });

    return { valid: true };
  }

  /**
   * Valida permissões
   */
  validatePermissions(permissions: string[]): {
    valid: boolean;
    invalidPermissions?: string[];
  } {
    const validPermissions = [
      'fs:read',
      'fs:write',
      'network:request',
      'env:read',
      'process:execute',
      'db:read',
      'db:write',
      'cache:read',
      'cache:write'
    ];

    const invalidPermissions = permissions.filter(
      p => !validPermissions.includes(p)
    );

    const valid = invalidPermissions.length === 0;

    this.log('permissions_validation', {
      valid,
      totalPermissions: permissions.length,
      invalidPermissions: invalidPermissions.length
    });

    if (!valid) {
      return { valid: false, invalidPermissions };
    }

    return { valid: true };
  }

  /**
   * Valida código do skill
   */
  validateCode(skillCode: string): {
    valid: boolean;
    issues: string[];
  } {
    const issues: string[] = [];

    // Verificar tamanho
    if (skillCode.length > 1000000) { // 1MB
      issues.push('Code exceeds maximum size of 1MB');
    }

    // Verificar caracteres nulos
    if (skillCode.includes('\0')) {
      issues.push('Code contains null characters');
    }

    // Verificar padrões perigosos
    const dangerousPatterns = [
      /require\s*\(\s*['"].*['"]\s*\)/,
      /import\s+.*\s+from\s+['"].*['"]/,
      /eval\s*\(/,
      /Function\s*\(/,
      /process\.exit/,
      /child_process/,
      /fs\.writeFileSync/
    ];

    for (const pattern of dangerousPatterns) {
      if (pattern.test(skillCode)) {
        issues.push(`Dangerous pattern detected: ${pattern.source}`);
      }
    }

    const valid = issues.length === 0;

    this.log('code_validation', {
      valid,
      codeSize: skillCode.length,
      issues: issues.length
    });

    return { valid, issues };
  }

  /**
   * Validação completa
   */
  fullValidation(
    skillCode: string,
    manifest: SkillManifest,
    authorPublicKey: string
  ): {
    valid: boolean;
    errors: string[];
  } {
    const errors: string[] = [];

    // 1. Validar manifesto
    const manifestCheck = this.validateManifestStructure(manifest);
    if (!manifestCheck.valid) {
      errors.push(`Manifest validation failed: ${manifestCheck.errors?.map(e => e.message).join(', ')}`);
    }

    // 2. Validar hash
    const hashCheck = this.validateHash(skillCode, manifest.hash);
    if (!hashCheck.valid) {
      errors.push(hashCheck.reason || 'Hash validation failed');
    }

    // 3. Validar assinatura
    const signatureCheck = this.validateSignature(
      skillCode,
      manifest.signature,
      authorPublicKey
    );
    if (!signatureCheck.valid) {
      errors.push(signatureCheck.reason || 'Signature validation failed');
    }

    // 4. Validar permissões
    const permissionsCheck = this.validatePermissions(manifest.permissions);
    if (!permissionsCheck.valid) {
      errors.push(
        `Invalid permissions: ${permissionsCheck.invalidPermissions?.join(', ')}`
      );
    }

    // 5. Validar código
    const codeCheck = this.validateCode(skillCode);
    if (!codeCheck.valid) {
      errors.push(...codeCheck.issues);
    }

    const valid = errors.length === 0;

    this.log('full_validation', {
      valid,
      skillName: manifest.name,
      skillVersion: manifest.version,
      errorCount: errors.length
    });

    return { valid, errors };
  }

  /**
   * Log de validação
   */
  private log(type: string, metadata: any = {}): void {
    this.validationLog.push({
      timestamp: new Date().toISOString(),
      type,
      ...metadata
    });

    // Manter últimos 10000 logs
    if (this.validationLog.length > 10000) {
      this.validationLog = this.validationLog.slice(-10000);
    }
  }

  /**
   * Obter logs
   */
  getLogs(limit: number = 100): any[] {
    return this.validationLog.slice(-limit);
  }

  /**
   * Relatório de validações
   */
  getReport(): {
    totalValidations: number;
    successfulValidations: number;
    failedValidations: number;
    successRate: string;
  } {
    const successful = this.validationLog.filter(
      l => l.valid === true || l.type === 'full_validation' && !l.errorCount
    ).length;
    const failed = this.validationLog.filter(
      l => l.valid === false || (l.type === 'full_validation' && l.errorCount > 0)
    ).length;
    const total = this.validationLog.length;

    return {
      totalValidations: total,
      successfulValidations: successful,
      failedValidations: failed,
      successRate: total > 0
        ? ((successful / total) * 100).toFixed(2) + '%'
        : '0%'
    };
  }
}

export default SkillValidator;
