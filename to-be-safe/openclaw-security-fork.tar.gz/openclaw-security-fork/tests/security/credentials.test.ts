import { describe, it, expect, beforeEach } from '@jest/globals';
import { SecureCredentialStore } from '../../src/security/credentials/secure-store';
import { CredentialEncryption } from '../../src/security/credentials/encryption';

describe('Credentials Security Tests', () => {
  let store: SecureCredentialStore;
  let encryption: CredentialEncryption;

  beforeEach(() => {
    store = new SecureCredentialStore();
    store.initialize('test-master-secret-at-least-32-characters-long-for-security');

    encryption = new CredentialEncryption();
    encryption.initialize('test-master-key-at-least-32-characters-for-encryption-security');
  });

  describe('Secure Store', () => {
    it('should store credential securely', async () => {
      const result = await store.storeCredential(
        'github',
        'user@example.com',
        'password123',
        'ghs_1234567890abcdefghij',
        ['github', 'repository']
      );

      expect(result.success).toBe(true);
      expect(result.id).toBeDefined();
      expect(result.id.length).toBe(32);
    });

    it('should retrieve credential', async () => {
      const storeResult = await store.storeCredential(
        'github',
        'user@example.com',
        'password123',
        'ghs_secret_token',
        []
      );

      const retrieveResult = await store.retrieveSecret(storeResult.id);

      expect(retrieveResult.success).toBe(true);
      expect(retrieveResult.secret).toBe('ghs_secret_token');
    });

    it('should validate password', async () => {
      const storeResult = await store.storeCredential(
        'github',
        'user@example.com',
        'mypassword',
        'secret_token',
        []
      );

      const isValid = await store.validatePassword(storeResult.id, 'mypassword');
      expect(isValid).toBe(true);

      const isInvalid = await store.validatePassword(storeResult.id, 'wrongpassword');
      expect(isInvalid).toBe(false);
    });

    it('should delete credential', async () => {
      const storeResult = await store.storeCredential(
        'github',
        'user@example.com',
        'password',
        'token',
        []
      );

      const deleted = store.deleteCredential(storeResult.id);
      expect(deleted).toBe(true);

      const retrieveResult = await store.retrieveSecret(storeResult.id);
      expect(retrieveResult.success).toBe(false);
    });

    it('should rotate credential', async () => {
      const storeResult = await store.storeCredential(
        'github',
        'user@example.com',
        'password',
        'old_token',
        []
      );

      const rotateResult = await store.rotateCredential(
        storeResult.id,
        'new_token'
      );

      expect(rotateResult.success).toBe(true);

      const retrieveResult = await store.retrieveSecret(storeResult.id);
      expect(retrieveResult.secret).toBe('new_token');
    });

    it('should list credentials', async () => {
      await store.storeCredential('github', 'user1@example.com', 'pass1', 'token1', []);
      await store.storeCredential('gitlab', 'user2@example.com', 'pass2', 'token2', []);
      await store.storeCredential('bitbucket', 'user3@example.com', 'pass3', 'token3', []);

      const credentials = store.listCredentials();

      expect(credentials.length).toBeGreaterThanOrEqual(3);
      expect(credentials.some(c => c.service === 'github')).toBe(true);
    });

    it('should get statistics', async () => {
      await store.storeCredential('github', 'user@example.com', 'pass', 'token', ['repo']);
      await store.storeCredential('gitlab', 'user@example.com', 'pass', 'token', ['api']);

      const stats = store.getStatistics();

      expect(stats.totalCredentials).toBeGreaterThan(0);
      expect(stats).toHaveProperty('byService');
      expect(stats).toHaveProperty('recentlyUsed');
      expect(stats).toHaveProperty('expiredCount');
    });

    it('should get audit logs', async () => {
      await store.storeCredential('github', 'user@example.com', 'pass', 'token', []);

      const logs = store.getAuditLogs(10);

      expect(logs.length).toBeGreaterThan(0);
      expect(logs[logs.length - 1]).toHaveProperty('timestamp');
    });
  });

  describe('Encryption', () => {
    it('should encrypt and decrypt', () => {
      const plaintext = 'This is a secret message';

      const encrypted = encryption.encrypt(plaintext);

      expect(encrypted.ciphertext).toBeDefined();
      expect(encrypted.iv).toBeDefined();
      expect(encrypted.tag).toBeDefined();
      expect(encrypted.algorithm).toBe('aes-256-gcm');

      const decrypted = encryption.decrypt(
        encrypted.ciphertext,
        encrypted.iv,
        encrypted.tag,
        encrypted.salt
      );

      expect(decrypted).toBe(plaintext);
    });

    it('should validate encryption integrity', () => {
      const plaintext = 'Secret data';
      const encrypted = encryption.encrypt(plaintext);

      const isValid = encryption.validateIntegrity(
        encrypted.ciphertext,
        encrypted.iv,
        encrypted.tag,
        encrypted.salt
      );

      expect(isValid).toBe(true);
    });

    it('should fail integrity check on tampered data', () => {
      const plaintext = 'Secret data';
      const encrypted = encryption.encrypt(plaintext);

      // Tamper with ciphertext
      const tamperedCiphertext = encrypted.ciphertext.slice(0, -2) + 'XX';

      const isValid = encryption.validateIntegrity(
        tamperedCiphertext,
        encrypted.iv,
        encrypted.tag,
        encrypted.salt
      );

      expect(isValid).toBe(false);
    });

    it('should generate salt', () => {
      const salt = encryption.generateSalt();

      expect(salt).toBeDefined();
      expect(salt.length).toBeGreaterThan(0);
    });

    it('should hash values', () => {
      const value = 'test value';
      const hash = encryption.hash(value);

      expect(hash).toBeDefined();
      expect(hash.length).toBe(64); // SHA256 hex length
    });

    it('should create HMAC', () => {
      const value = 'test value';
      const hmac = encryption.hmac(value);

      expect(hmac).toBeDefined();
      expect(hmac.length).toBe(64); // SHA256 hex length
    });

    it('should get statistics', () => {
      encryption.encrypt('test data');

      const stats = encryption.getStatistics();

      expect(stats).toHaveProperty('algorithm');
      expect(stats).toHaveProperty('ivLength');
      expect(stats.algorithm).toBe('aes-256-gcm');
    });
  });

  describe('Error Handling', () => {
    it('should reject uninitialized store', async () => {
      const uninitializedStore = new SecureCredentialStore();

      const result = await uninitializedStore.storeCredential(
        'github',
        'user@example.com',
        'pass',
        'token',
        []
      );

      expect(result.success).toBe(false);
      expect(result.error).toBeDefined();
    });

    it('should reject invalid input', async () => {
      const result = await store.storeCredential(
        '',
        'user@example.com',
        'pass',
        '',
        []
      );

      expect(result.success).toBe(false);
    });
  });
});
