import { describe, it, expect, beforeEach } from '@jest/globals';
import { CSRFProtection } from '../../src/security/web/csrf-protection';
import { XSSSanitizer } from '../../src/security/web/xss-sanitizer';
import { CORSManager } from '../../src/security/web/cors-manager';
import { SecurityHeaders } from '../../src/security/web/security-headers';

describe('Web Security Tests', () => {
  describe('CSRF Protection', () => {
    let csrf: CSRFProtection;
    const sessionId = 'test-session-123';

    beforeEach(() => {
      csrf = new CSRFProtection();
    });

    it('should generate CSRF token', () => {
      const token = csrf.generateToken(sessionId);

      expect(token).toBeDefined();
      expect(typeof token).toBe('string');
      expect(token.length).toBeGreaterThan(0);
    });

    it('should validate valid CSRF token', () => {
      const token = csrf.generateToken(sessionId);
      const result = csrf.validateToken(token, sessionId);

      expect(result.valid).toBe(true);
    });

    it('should reject invalid CSRF token', () => {
      const result = csrf.validateToken('invalid-token-123', sessionId);

      expect(result.valid).toBe(false);
      expect(result.reason).toContain('not found');
    });

    it('should reject token from different session', () => {
      const token = csrf.generateToken('session-1');
      const result = csrf.validateToken(token, 'session-2');

      expect(result.valid).toBe(false);
      expect(result.reason).toContain('mismatch');
    });

    it('should enforce single-use tokens', () => {
      const token = csrf.generateToken(sessionId);

      // First validation
      const result1 = csrf.validateToken(token, sessionId);
      expect(result1.valid).toBe(true);

      // Second validation should fail
      const result2 = csrf.validateToken(token, sessionId);
      expect(result2.valid).toBe(false);
    });

    it('should invalidate session tokens', () => {
      csrf.generateToken(sessionId);
      csrf.generateToken(sessionId);

      const count = csrf.invalidateSessionTokens(sessionId);

      expect(count).toBe(2);
    });

    it('should get statistics', () => {
      csrf.generateToken('session-1');
      csrf.generateToken('session-2');

      const stats = csrf.getStatistics();

      expect(stats.activeTokens).toBeGreaterThan(0);
      expect(stats).toHaveProperty('activeSessions');
    });

    afterEach(() => {
      csrf.stopCleanup();
    });
  });

  describe('XSS Sanitizer', () => {
    let sanitizer: XSSSanitizer;

    beforeEach(() => {
      sanitizer = new XSSSanitizer();
    });

    it('should sanitize malicious scripts', () => {
      const malicious = '<img src=x onerror="alert(\'XSS\')">';
      const result = sanitizer.sanitize(malicious);

      expect(result.sanitized).not.toContain('onerror');
      expect(result.threats.length).toBeGreaterThan(0);
    });

    it('should allow safe HTML', () => {
      const safe = '<b>Bold text</b>';
      const result = sanitizer.sanitize(safe);

      expect(result.sanitized).toContain('<b>');
      expect(result.isClean).toBe(true);
    });

    it('should escape HTML in strict mode', () => {
      const input = '<p>Paragraph</p>';
      const result = sanitizer.sanitize(input, true);

      expect(result.sanitized).not.toContain('<p>');
    });

    it('should sanitize objects', () => {
      const obj = {
        name: 'User',
        bio: '<script>alert("XSS")</script>',
        email: 'user@example.com'
      };

      const result = sanitizer.sanitizeObject(obj);

      expect(result.sanitized.name).toBe('User');
      expect(result.sanitized.bio).not.toContain('<script>');
    });

    it('should validate attributes', () => {
      const safe = sanitizer.isAttributeSafe('href', 'https://example.com');
      expect(safe).toBe(true);

      const unsafe = sanitizer.isAttributeSafe('onclick', 'alert("XSS")');
      expect(unsafe).toBe(false);
    });

    it('should escape HTML', () => {
      const text = '<script>alert("XSS")</script>';
      const escaped = sanitizer.escapeHtml(text);

      expect(escaped).not.toContain('<script>');
      expect(escaped).toContain('&lt;');
    });
  });

  describe('CORS Manager', () => {
    let cors: CORSManager;

    beforeEach(() => {
      cors = new CORSManager({
        allowedOrigins: ['http://localhost:3000', 'https://yourdomain.com'],
        allowedMethods: ['GET', 'POST', 'PUT', 'DELETE'],
        allowedHeaders: ['Content-Type', 'Authorization']
      });
    });

    it('should add and remove origins', () => {
      cors.addOrigin('https://new-domain.com');
      expect(cors.getConfig().allowedOrigins).toContain('https://new-domain.com');

      cors.removeOrigin('https://new-domain.com');
      expect(cors.getConfig().allowedOrigins).not.toContain('https://new-domain.com');
    });

    it('should add methods', () => {
      cors.addMethod('PATCH');
      expect(cors.getConfig().allowedMethods).toContain('PATCH');
    });

    it('should add headers', () => {
      cors.addHeader('X-Custom-Header');
      expect(cors.getConfig().allowedHeaders).toContain('X-Custom-Header');
    });

    it('should validate preflight requests', () => {
      const mockReq = {
        method: 'OPTIONS',
        headers: {
          origin: 'http://localhost:3000',
          'access-control-request-method': 'POST'
        }
      } as any;

      const result = cors.validatePreflight(mockReq);
      expect(result.valid).toBe(true);
    });

    it('should reject invalid preflight', () => {
      const mockReq = {
        method: 'OPTIONS',
        headers: {
          origin: 'http://malicious-site.com',
          'access-control-request-method': 'POST'
        }
      } as any;

      const result = cors.validatePreflight(mockReq);
      expect(result.valid).toBe(false);
    });

    it('should get report', () => {
      const report = cors.getReport();

      expect(report).toHaveProperty('whitelistedOrigins');
      expect(report).toHaveProperty('allowedMethods');
      expect(report).toHaveProperty('allowedHeaders');
    });
  });

  describe('Security Headers', () => {
    let headers: SecurityHeaders;

    beforeEach(() => {
      headers = new SecurityHeaders();
    });

    it('should provide default CSP', () => {
      const config = headers.getConfig();

      expect(config.contentSecurityPolicy).toBeDefined();
      expect(config.contentSecurityPolicy).toContain('default-src');
    });

    it('should update CSP', () => {
      const newCSP = "default-src 'none'";
      headers.updateCSP(newCSP);

      const config = headers.getConfig();
      expect(config.contentSecurityPolicy).toBe(newCSP);
    });

    it('should add CSP directive', () => {
      headers.addCSPDirective('img-src', "'self' data:");

      const config = headers.getConfig();
      expect(config.contentSecurityPolicy).toContain('img-src');
    });

    it('should update X-Frame-Options', () => {
      headers.updateXFrameOptions('SAMEORIGIN');

      const config = headers.getConfig();
      expect(config.xFrameOptions).toBe('SAMEORIGIN');
    });

    it('should update HSTS', () => {
      headers.updateHSTS(63072000, true, true);

      const config = headers.getConfig();
      expect(config.strictTransportSecurity).toContain('63072000');
    });

    it('should get report', () => {
      const report = headers.getReport();

      expect(report).toHaveProperty('cspEnabled');
      expect(report).toHaveProperty('xssProtectionEnabled');
      expect(report).toHaveProperty('hstsEnabled');
    });
  });
});
