import crypto, { randomBytes } from 'crypto';
import bcrypt from 'bcrypt';

export interface StoredCredential {
  id: string;
  service: string;
  username: string;
  passwordHash: string;
  secretEncrypted: string;
  encryptionIv: string;
  encryptionTag: string;
  metadata: {
    createdAt: number;
    lastUsed: number;
    rotatedAt: number;
    algorithm: string;
  };
  tags: string[];
  accessLog: Array<{
    timestamp: number;
    context: string;
    success: boolean;
  }>;
}

/**
 * Armazém seguro de credenciais
 * Implementa criptografia, hash de senha e auditoria
 */
export class SecureCredentialStore {
  private store = new Map<string, StoredCredential>();
  private readonly ALGORITHM = 'aes-256-gcm';
  private readonly BCRYPT_ROUNDS = 12;
  private readonly MAX_CREDENTIAL_AGE = 90 * 24 * 60 * 60 * 1000; // 90 dias
  private encryptionKey: Buffer | null = null;
  private salt: string = '';
  private auditLog: any[] = [];

  /**
   * Inicializa o armazém com chave de criptografia
   */
  initialize(masterSecret: string, salt?: string): void {
    if (!masterSecret || masterSecret.length < 32) {
      throw new Error('Master secret must be at least 32 characters');
    }

    this.salt = salt || randomBytes(16).toString('hex');

    // Usar scrypt para derivação de chave
    this.encryptionKey = crypto.scryptSync(masterSecret, this.salt, 32);

    console.log('✓ Credential store initialized');
  }

  /**
   * Criptografa um secret
   */
  private encryptSecret(
    secret: string
  ): { encrypted: string; iv: string; tag: string } {
    if (!this.encryptionKey) {
      throw new Error('Encryption key not initialized');
    }

    const iv = randomBytes(16);
    const cipher = crypto.createCipheriv(
      this.ALGORITHM,
      this.encryptionKey,
      iv
    );

    let encrypted = cipher.update(secret, 'utf-8', 'hex');
    encrypted += cipher.final('hex');

    const tag = (cipher as any).getAuthTag().toString('hex');

    return {
      encrypted,
      iv: iv.toString('hex'),
      tag
    };
  }

  /**
   * Descriptografa um secret
   */
  private decryptSecret(
    encrypted: string,
    iv: string,
    tag: string
  ): string {
    if (!this.encryptionKey) {
      throw new Error('Encryption key not initialized');
    }

    const decipher = crypto.createDecipheriv(
      this.ALGORITHM,
      this.encryptionKey,
      Buffer.from(iv, 'hex')
    );

    (decipher as any).setAuthTag(Buffer.from(tag, 'hex'));

    let decrypted = decipher.update(encrypted, 'hex', 'utf-8');
    decrypted += decipher.final('utf-8');

    return decrypted;
  }

  /**
   * Armazena credencial de forma segura
   */
  async storeCredential(
    service: string,
    username: string,
    password: string,
    secret: string,
    tags: string[] = []
  ): Promise<{ id: string; success: boolean; error?: string }> {
    try {
      // Validar entrada
      if (!service || !username || (!password && !secret)) {
        return {
          id: '',
          success: false,
          error: 'service, username, and either password or secret required'
        };
      }

      // Gerar hash seguro da senha
      const passwordHash = password
        ? await bcrypt.hash(password, this.BCRYPT_ROUNDS)
        : 'N/A';

      // Criptografar secret
      const { encrypted, iv, tag } = this.encryptSecret(secret);

      // Gerar ID único
      const id = crypto.randomBytes(16).toString('hex');

      // Criar estrutura de credencial
      const credential: StoredCredential = {
        id,
        service,
        username,
        passwordHash,
        secretEncrypted: encrypted,
        encryptionIv: iv,
        encryptionTag: tag,
        metadata: {
          createdAt: Date.now(),
          lastUsed: 0,
          rotatedAt: Date.now(),
          algorithm: this.ALGORITHM
        },
        tags: tags.filter(t => /^[a-zA-Z0-9-_]{1,50}$/.test(t)),
        accessLog: []
      };

      this.store.set(id, credential);
      this.logAction('store_credential', {
        credentialId: id,
        service,
        success: true
      });

      return {
        id,
        success: true
      };
    } catch (error: any) {
      this.logAction('store_credential', {
        service,
        success: false,
        error: error.message
      });

      return {
        id: '',
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Recupera credencial de forma segura
   */
  async retrieveSecret(
    credentialId: string,
    context: string = 'unknown'
  ): Promise<{ secret?: string; success: boolean; error?: string }> {
    try {
      // Validar entrada
      if (!credentialId || typeof credentialId !== 'string') {
        return { success: false, error: 'Invalid credential ID' };
      }

      const credential = this.store.get(credentialId);

      if (!credential) {
        return { success: false, error: 'Credential not found' };
      }

      // Validar idade da credencial
      const age = Date.now() - credential.metadata.createdAt;
      if (age > this.MAX_CREDENTIAL_AGE) {
        return {
          success: false,
          error: `Credential expired. Age: ${Math.round(age / (24 * 60 * 60 * 1000))} days`
        };
      }

      // Descriptografar
      const secret = this.decryptSecret(
        credential.secretEncrypted,
        credential.encryptionIv,
        credential.encryptionTag
      );

      // Registrar acesso
      credential.metadata.lastUsed = Date.now();
      credential.accessLog.push({
        timestamp: Date.now(),
        context,
        success: true
      });

      this.logAction('retrieve_secret', {
        credentialId,
        context,
        success: true
      });

      return { secret, success: true };
    } catch (error: any) {
      this.logAction('retrieve_secret', {
        credentialId,
        context,
        success: false,
        error: error.message
      });

      return {
        success: false,
        error: 'Failed to retrieve credential'
      };
    }
  }

  /**
   * Valida senha contra hash armazenado
   */
  async validatePassword(
    credentialId: string,
    password: string
  ): Promise<boolean> {
    try {
      const credential = this.store.get(credentialId);
      if (!credential) return false;

      return await bcrypt.compare(password, credential.passwordHash);
    } catch (error) {
      console.error('Password validation error:', error);
      return false;
    }
  }

  /**
   * Deleta credencial
   */
  deleteCredential(credentialId: string): boolean {
    const deleted = this.store.delete(credentialId);
    if (deleted) {
      this.logAction('delete_credential', {
        credentialId,
        success: true
      });
    }
    return deleted;
  }

  /**
   * Rotaciona credencial
   */
  async rotateCredential(
    credentialId: string,
    newSecret: string
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const credential = this.store.get(credentialId);
      if (!credential) {
        return { success: false, error: 'Credential not found' };
      }

      // Criptografar novo secret
      const { encrypted, iv, tag } = this.encryptSecret(newSecret);

      // Atualizar
      credential.secretEncrypted = encrypted;
      credential.encryptionIv = iv;
      credential.encryptionTag = tag;
      credential.metadata.rotatedAt = Date.now();

      this.logAction('rotate_credential', {
        credentialId,
        success: true
      });

      return { success: true };
    } catch (error: any) {
      this.logAction('rotate_credential', {
        credentialId,
        success: false,
        error: error.message
      });

      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Log de ações
   */
  private logAction(type: string, metadata: any = {}): void {
    this.auditLog.push({
      timestamp: new Date().toISOString(),
      type,
      ...metadata
    });

    // Manter últimos 10000 logs
    if (this.auditLog.length > 10000) {
      this.auditLog = this.auditLog.slice(-10000);
    }
  }

  /**
   * Obter logs de auditoria
   */
  getAuditLogs(limit: number = 100): any[] {
    return this.auditLog.slice(-limit);
  }

  /**
   * Listar todas as credenciais (apenas metadados)
   */
  listCredentials(): Array<{
    id: string;
    service: string;
    username: string;
    createdAt: number;
    lastUsed: number;
    tags: string[];
  }> {
    const list: Array<any> = [];

    for (const [id, credential] of this.store.entries()) {
      list.push({
        id,
        service: credential.service,
        username: credential.username,
        createdAt: credential.metadata.createdAt,
        lastUsed: credential.metadata.lastUsed,
        tags: credential.tags
      });
    }

    return list;
  }

  /**
   * Obter estatísticas
   */
  getStatistics(): {
    totalCredentials: number;
    byService: Record<string, number>;
    recentlyUsed: number;
    expiredCount: number;
    totalAuditLogs: number;
  } {
    const stats = {
      totalCredentials: this.store.size,
      byService: {} as Record<string, number>,
      recentlyUsed: 0,
      expiredCount: 0,
      totalAuditLogs: this.auditLog.length
    };

    const now = Date.now();
    const thirtyDaysAgo = now - 30 * 24 * 60 * 60 * 1000;

    for (const credential of this.store.values()) {
      // Contar por serviço
      stats.byService[credential.service] =
        (stats.byService[credential.service] || 0) + 1;

      // Contar recentemente usados
      if (credential.metadata.lastUsed > thirtyDaysAgo) {
        stats.recentlyUsed++;
      }

      // Contar expirados
      if (now - credential.metadata.createdAt > this.MAX_CREDENTIAL_AGE) {
        stats.expiredCount++;
      }
    }

    return stats;
  }
}

export default SecureCredentialStore;
