import { Request, Response, NextFunction } from 'express';

export interface SecurityHeadersConfig {
  contentSecurityPolicy: string;
  xFrameOptions: string;
  xContentTypeOptions: string;
  xXssProtection: string;
  strictTransportSecurity: string;
  referrerPolicy: string;
  permissionsPolicy: string;
}

/**
 * Gerenciador de Security Headers
 * Define headers HTTP de segurança
 */
export class SecurityHeaders {
  private config: SecurityHeadersConfig;
  private validationLog: any[] = [];

  constructor(config?: Partial<SecurityHeadersConfig>) {
    this.config = {
      contentSecurityPolicy: config?.contentSecurityPolicy || this.getDefaultCSP(),
      xFrameOptions: config?.xFrameOptions || 'DENY',
      xContentTypeOptions: config?.xContentTypeOptions || 'nosniff',
      xXssProtection: config?.xXssProtection || '1; mode=block',
      strictTransportSecurity:
        config?.strictTransportSecurity || 'max-age=31536000; includeSubDomains; preload',
      referrerPolicy: config?.referrerPolicy || 'strict-no-referrer',
      permissionsPolicy: config?.permissionsPolicy || this.getDefaultPermissionsPolicy()
    };
  }

  /**
   * Obter CSP padrão
   */
  private getDefaultCSP(): string {
    return [
      "default-src 'self'",
      "script-src 'self'",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: https:",
      "font-src 'self'",
      "connect-src 'self'",
      "frame-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "upgrade-insecure-requests"
    ].join('; ');
  }

  /**
   * Obter Permissions Policy padrão
   */
  private getDefaultPermissionsPolicy(): string {
    return [
      'accelerometer=()',
      'camera=()',
      'geolocation=()',
      'gyroscope=()',
      'magnetometer=()',
      'microphone=()',
      'payment=()',
      'usb=()'
    ].join(', ');
  }

  /**
   * Middleware de headers de segurança
   */
  middleware() {
    return (req: Request, res: Response, next: NextFunction) => {
      // Content Security Policy
      res.setHeader('Content-Security-Policy', this.config.contentSecurityPolicy);

      // Clickjacking protection
      res.setHeader('X-Frame-Options', this.config.xFrameOptions);

      // MIME type sniffing prevention
      res.setHeader('X-Content-Type-Options', this.config.xContentTypeOptions);

      // XSS protection
      res.setHeader('X-XSS-Protection', this.config.xXssProtection);

      // HSTS
      res.setHeader('Strict-Transport-Security', this.config.strictTransportSecurity);

      // Referrer policy
      res.setHeader('Referrer-Policy', this.config.referrerPolicy);

      // Permissions policy
      res.setHeader('Permissions-Policy', this.config.permissionsPolicy);

      // Adicionar headers customizados de segurança
      res.setHeader('X-Content-Security-Policy', this.config.contentSecurityPolicy);
      res.setHeader('X-WebKit-CSP', this.config.contentSecurityPolicy);

      // Remover header de versão
      res.removeHeader('X-Powered-By');
      res.removeHeader('Server');

      this.log('headers_set', `Headers set for ${req.method} ${req.path}`, {
        method: req.method,
        path: req.path
      });

      next();
    };
  }

  /**
   * Atualizar CSP
   */
  updateCSP(policy: string): void {
    this.config.contentSecurityPolicy = policy;
    console.log('✓ CSP updated');
  }

  /**
   * Adicionar diretiva CSP
   */
  addCSPDirective(directive: string, value: string): void {
    const policies = this.config.contentSecurityPolicy.split('; ');
    const newDirective = `${directive} ${value}`;

    // Verificar se diretiva já existe
    const exists = policies.some(p => p.startsWith(directive));
    if (!exists) {
      policies.push(newDirective);
      this.config.contentSecurityPolicy = policies.join('; ');
      console.log(`✓ Added CSP directive: ${directive}`);
    }
  }

  /**
   * Atualizar X-Frame-Options
   */
  updateXFrameOptions(value: string): void {
    this.config.xFrameOptions = value;
    console.log(`✓ X-Frame-Options updated to: ${value}`);
  }

  /**
   * Atualizar HSTS
   */
  updateHSTS(maxAge: number, includeSubDomains: boolean = true, preload: boolean = true): void {
    let hsts = `max-age=${maxAge}`;
    if (includeSubDomains) hsts += '; includeSubDomains';
    if (preload) hsts += '; preload';

    this.config.strictTransportSecurity = hsts;
    console.log(`✓ HSTS updated to: ${hsts}`);
  }

  /**
   * Log de eventos
   */
  private log(type: string, message: string, metadata: any = {}): void {
    this.validationLog.push({
      timestamp: new Date().toISOString(),
      type,
      message,
      ...metadata
    });

    // Manter últimos 10000 logs
    if (this.validationLog.length > 10000) {
      this.validationLog = this.validationLog.slice(-10000);
    }
  }

  /**
   * Obter logs
   */
  getLogs(limit: number = 100): any[] {
    return this.validationLog.slice(-limit);
  }

  /**
   * Obter configuração atual
   */
  getConfig(): SecurityHeadersConfig {
    return { ...this.config };
  }

  /**
   * Relatório de headers
   */
  getReport(): {
    totalRequests: number;
    cspEnabled: boolean;
    clickjackingProtection: string;
    xssProtectionEnabled: boolean;
    hstsEnabled: boolean;
    permissionsPolicyEnabled: boolean;
  } {
    return {
      totalRequests: this.validationLog.filter(l => l.type === 'headers_set').length,
      cspEnabled: !!this.config.contentSecurityPolicy,
      clickjackingProtection: this.config.xFrameOptions,
      xssProtectionEnabled: !!this.config.xXssProtection,
      hstsEnabled: !!this.config.strictTransportSecurity,
      permissionsPolicyEnabled: !!this.config.permissionsPolicy
    };
  }
}

export default SecurityHeaders;
