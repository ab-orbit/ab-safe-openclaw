import crypto from 'crypto';

/**
 * Verificador de Assinatura Digital
 * Valida autenticidade usando RSA/ECDSA
 */
export class SignatureVerifier {
  private publicKeys = new Map<string, string>();
  private trustedAuthors = new Set<string>();
  private validationLog: any[] = [];

  /**
   * Registra chave pública de autor
   */
  registerAuthorPublicKey(authorId: string, publicKey: string): void {
    // Validar formato da chave
    if (!publicKey.includes('BEGIN PUBLIC KEY')) {
      throw new Error('Invalid public key format');
    }

    this.publicKeys.set(authorId, publicKey);
    console.log(`✓ Registered public key for author: ${authorId}`);
  }

  /**
   * Adiciona autor confiável
   */
  trustAuthor(authorId: string): void {
    if (!this.publicKeys.has(authorId)) {
      throw new Error(`Public key not registered for author: ${authorId}`);
    }

    this.trustedAuthors.add(authorId);
    console.log(`✓ Marked author as trusted: ${authorId}`);
  }

  /**
   * Remove autor confiável
   */
  untrustAuthor(authorId: string): void {
    this.trustedAuthors.delete(authorId);
    console.log(`✓ Removed author from trusted list: ${authorId}`);
  }

  /**
   * Verifica se autor é confiável
   */
  isAuthorTrusted(authorId: string): boolean {
    return this.trustedAuthors.has(authorId);
  }

  /**
   * Verifica assinatura de dados
   */
  verifySignature(
    data: string,
    signature: string,
    authorId: string,
    algorithm: string = 'sha256'
  ): {
    valid: boolean;
    trusted: boolean;
    reason?: string;
  } {
    try {
      const publicKey = this.publicKeys.get(authorId);

      if (!publicKey) {
        this.log('signature_verification', {
          valid: false,
          authorId,
          reason: 'Public key not found'
        });

        return {
          valid: false,
          trusted: false,
          reason: 'Public key not registered'
        };
      }

      // Verificar assinatura
      const verifier = crypto.createVerify(algorithm);
      verifier.update(data);

      const isValid = verifier.verify(
        publicKey,
        Buffer.from(signature, 'hex')
      );

      const isTrusted = this.isAuthorTrusted(authorId);

      this.log('signature_verification', {
        valid: isValid,
        trusted: isTrusted,
        authorId,
        algorithm
      });

      if (!isValid) {
        return {
          valid: false,
          trusted: false,
          reason: 'Signature verification failed'
        };
      }

      return {
        valid: true,
        trusted: isTrusted
      };
    } catch (error: any) {
      this.log('signature_verification', {
        valid: false,
        authorId,
        error: error.message
      });

      return {
        valid: false,
        trusted: false,
        reason: error.message
      };
    }
  }

  /**
   * Cria assinatura para dados
   */
  createSignature(
    data: string,
    privateKey: string,
    algorithm: string = 'sha256'
  ): {
    signature: string;
    algorithm: string;
  } {
    try {
      const signer = crypto.createSign(algorithm);
      signer.update(data);

      const signature = signer.sign(privateKey, 'hex');

      return {
        signature,
        algorithm
      };
    } catch (error: any) {
      throw new Error(`Failed to create signature: ${error.message}`);
    }
  }

  /**
   * Gera par de chaves RSA
   */
  generateKeyPair(modulusLength: number = 2048): {
    publicKey: string;
    privateKey: string;
  } {
    const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
      modulusLength,
      publicKeyEncoding: {
        type: 'spki',
        format: 'pem'
      },
      privateKeyEncoding: {
        type: 'pkcs8',
        format: 'pem'
      }
    });

    return {
      publicKey,
      privateKey
    };
  }

  /**
   * Log de verificação
   */
  private log(type: string, metadata: any = {}): void {
    this.validationLog.push({
      timestamp: new Date().toISOString(),
      type,
      ...metadata
    });

    // Manter últimos 10000 logs
    if (this.validationLog.length > 10000) {
      this.validationLog = this.validationLog.slice(-10000);
    }
  }

  /**
   * Obter logs
   */
  getLogs(limit: number = 100): any[] {
    return this.validationLog.slice(-limit);
  }

  /**
   * Relatório
   */
  getReport(): {
    totalVerifications: number;
    successfulVerifications: number;
    failedVerifications: number;
    registeredAuthors: number;
    trustedAuthors: number;
    successRate: string;
  } {
    const successful = this.validationLog.filter(l => l.valid).length;
    const failed = this.validationLog.filter(l => !l.valid).length;
    const total = this.validationLog.length;

    return {
      totalVerifications: total,
      successfulVerifications: successful,
      failedVerifications: failed,
      registeredAuthors: this.publicKeys.size,
      trustedAuthors: this.trustedAuthors.size,
      successRate: total > 0
        ? ((successful / total) * 100).toFixed(2) + '%'
        : '0%'
    };
  }

  /**
   * Obter autores confiáveis
   */
  getTrustedAuthors(): string[] {
    return Array.from(this.trustedAuthors);
  }

  /**
   * Obter autores registrados
   */
  getRegisteredAuthors(): string[] {
    return Array.from(this.publicKeys.keys());
  }
}

export default SignatureVerifier;
