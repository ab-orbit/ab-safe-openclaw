import { Request, Response, NextFunction } from 'express';

export interface CORSConfig {
  allowedOrigins: string[];
  allowedMethods: string[];
  allowedHeaders: string[];
  exposedHeaders: string[];
  allowCredentials: boolean;
  maxAge: number;
}

/**
 * Gerenciador de CORS (Cross-Origin Resource Sharing)
 * Implementa validação rigorosa de origem
 */
export class CORSManager {
  private config: CORSConfig;
  private validationLog: any[] = [];

  constructor(config: Partial<CORSConfig> = {}) {
    this.config = {
      allowedOrigins: config.allowedOrigins || [],
      allowedMethods: config.allowedMethods || ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
      allowedHeaders: config.allowedHeaders || ['Content-Type', 'Authorization'],
      exposedHeaders: config.exposedHeaders || ['X-Total-Count'],
      allowCredentials: config.allowCredentials !== false,
      maxAge: config.maxAge || 3600
    };
  }

  /**
   * Middleware CORS
   */
  middleware() {
    return (req: Request, res: Response, next: NextFunction) => {
      const origin = req.headers.origin;

      // Validar origem
      if (origin && this.isOriginAllowed(origin)) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader(
          'Access-Control-Allow-Credentials',
          String(this.config.allowCredentials)
        );
        res.setHeader(
          'Access-Control-Allow-Methods',
          this.config.allowedMethods.join(', ')
        );
        res.setHeader(
          'Access-Control-Allow-Headers',
          this.config.allowedHeaders.join(', ')
        );
        res.setHeader(
          'Access-Control-Expose-Headers',
          this.config.exposedHeaders.join(', ')
        );
        res.setHeader('Access-Control-Max-Age', String(this.config.maxAge));

        // Remover credenciais se permitidas
        if (this.config.allowCredentials) {
          res.setHeader('Access-Control-Allow-Credentials', 'true');
        }

        this.log('cors_allowed', `Origin: ${origin}`, {
          origin,
          method: req.method
        });
      } else if (origin) {
        this.log('cors_rejected', `Origin not allowed: ${origin}`, {
          origin,
          method: req.method,
          ip: req.ip
        });
      }

      // Handle preflight
      if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
      }

      next();
    };
  }

  /**
   * Valida se origem é permitida
   */
  private isOriginAllowed(origin: string): boolean {
    return this.config.allowedOrigins.some(allowed => {
      if (allowed === '*') return true; // Use com cuidado
      return allowed === origin;
    });
  }

  /**
   * Adiciona origem permitida
   */
  addOrigin(origin: string): void {
    if (!this.config.allowedOrigins.includes(origin)) {
      this.config.allowedOrigins.push(origin);
      console.log(`✓ Added CORS origin: ${origin}`);
    }
  }

  /**
   * Remove origem permitida
   */
  removeOrigin(origin: string): void {
    const index = this.config.allowedOrigins.indexOf(origin);
    if (index > -1) {
      this.config.allowedOrigins.splice(index, 1);
      console.log(`✓ Removed CORS origin: ${origin}`);
    }
  }

  /**
   * Adiciona método permitido
   */
  addMethod(method: string): void {
    const m = method.toUpperCase();
    if (!this.config.allowedMethods.includes(m)) {
      this.config.allowedMethods.push(m);
      console.log(`✓ Added CORS method: ${m}`);
    }
  }

  /**
   * Adiciona header permitido
   */
  addHeader(header: string): void {
    if (!this.config.allowedHeaders.includes(header)) {
      this.config.allowedHeaders.push(header);
      console.log(`✓ Added CORS header: ${header}`);
    }
  }

  /**
   * Log de validação
   */
  private log(type: string, message: string, metadata: any = {}): void {
    this.validationLog.push({
      timestamp: new Date().toISOString(),
      type,
      message,
      ...metadata
    });

    // Manter últimos 10000 logs
    if (this.validationLog.length > 10000) {
      this.validationLog = this.validationLog.slice(-10000);
    }
  }

  /**
   * Obter logs
   */
  getLogs(limit: number = 100): any[] {
    return this.validationLog.slice(-limit);
  }

  /**
   * Relatório CORS
   */
  getReport(): {
    totalRequests: number;
    allowedRequests: number;
    rejectedRequests: number;
    rejectionRate: string;
    whitelistedOrigins: number;
    allowedMethods: number;
    allowedHeaders: number;
  } {
    const allowed = this.validationLog.filter(l => l.type === 'cors_allowed').length;
    const rejected = this.validationLog.filter(l => l.type === 'cors_rejected').length;
    const total = this.validationLog.length;

    return {
      totalRequests: total,
      allowedRequests: allowed,
      rejectedRequests: rejected,
      rejectionRate: total > 0
        ? ((rejected / total) * 100).toFixed(2) + '%'
        : '0%',
      whitelistedOrigins: this.config.allowedOrigins.length,
      allowedMethods: this.config.allowedMethods.length,
      allowedHeaders: this.config.allowedHeaders.length
    };
  }

  /**
   * Obter configuração atual
   */
  getConfig(): CORSConfig {
    return { ...this.config };
  }

  /**
   * Validar preflight request
   */
  validatePreflight(req: Request): {
    valid: boolean;
    reason?: string;
  } {
    if (req.method !== 'OPTIONS') {
      return { valid: true };
    }

    const origin = req.headers.origin;
    const method = req.headers['access-control-request-method'];

    if (!origin) {
      return {
        valid: false,
        reason: 'Missing Origin header'
      };
    }

    if (!this.isOriginAllowed(origin)) {
      return {
        valid: false,
        reason: `Origin not allowed: ${origin}`
      };
    }

    if (method && !this.config.allowedMethods.includes(method as string)) {
      return {
        valid: false,
        reason: `Method not allowed: ${method}`
      };
    }

    return { valid: true };
  }
}

export default CORSManager;
